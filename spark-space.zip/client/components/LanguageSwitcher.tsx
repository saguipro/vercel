import { useTranslation } from "@/hooks/useTranslation";
import { Language } from "@/lib/translations";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const languageOptions: { value: Language; label: string; flag: string }[] = [
  { value: "he", label: "עברית", flag: "🇮🇱" },
  { value: "en", label: "English", flag: "🇬🇧" },
  { value: "zh", label: "中文", flag: "🇨🇳" },
  { value: "ja", label: "日本語", flag: "🇯🇵" },
  { value: "fr", label: "Français", flag: "🇫🇷" },
  { value: "hi", label: "हिन्दी", flag: "🇮🇳" },
  { value: "es", label: "Español", flag: "🇪🇸" },
  { value: "de", label: "Deutsch", flag: "🇩🇪" },
];

export default function LanguageSwitcher() {
  const { language, setLanguage, t } = useTranslation();

  return (
    <div className="px-4 py-3 border-t border-sidebar-border">
      <label className="text-xs text-sidebar-foreground opacity-70 block mb-2">
        {t("language")}
      </label>
      <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
        <SelectTrigger className="w-full bg-sidebar-accent text-sidebar-foreground border-sidebar-border hover:bg-sidebar-accent/80">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {languageOptions.map((option) => (
            <SelectItem key={option.value} value={option.value}>
              <span className="flex items-center gap-2">
                {option.flag} {option.label}
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
