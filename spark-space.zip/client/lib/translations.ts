export type Language = "he" | "en" | "zh" | "ja" | "fr" | "hi" | "es" | "de";

export interface TranslationsType {
  // Navigation
  dashboard: string;
  income: string;
  expenses: string;
  savings: string;
  investments: string;
  crypto: string;
  goals: string;
  family: string;
  advisor: string;
  scenarioAnalysis: string;
  education: string;

  // App Name
  appName: string;
  copyright: string;

  // Dashboard Page
  financialOverview: string;
  trackIncomeExpenses: string;
  totalIncome: string;
  totalExpenses: string;
  currentBalance: string;
  savingsGoal: string;
  incomeVsExpenses: string;
  expenseBreakdown: string;
  balanceTrend: string;
  recentTransactions: string;

  // Dashboard Cards
  up: string;
  down: string;
  completed: string;

  // Table Headers
  description: string;
  date: string;
  amount: string;
  status: string;
  source: string;

  // Income Page
  incomeManagement: string;
  trackIncomeStreams: string;
  totalMonthlyIncome: string;
  incomeStreams: string;
  averageMonthly: string;
  activeIncomeStreams: string;
  frequency: string;
  next: string;
  addIncomeStream: string;
  regular: string;
  variable: string;
  incomeHistory: string;
  received: string;

  // Transaction Types
  salaryDeposit: string;
  groceryShopping: string;
  gymMembership: string;
  freelancePayment: string;
  electricBill: string;
  freelanceProjects: string;
  investmentsDividend: string;
  sideHustle: string;

  // Placeholder Pages
  expenseTracking: string;
  monitorManageExpenses: string;
  savingsGoalsTitle: string;
  setTrackGoals: string;
  investmentPortfolio: string;
  trackStocksBonds: string;
  cryptoHoldings: string;
  monitorCryptoPortfolio: string;
  financialGoalsTitle: string;
  createManageGoals: string;
  familyFinance: string;
  manageFamilyBudgets: string;
  financialAdvisor: string;
  getPersonalizedAdvice: string;
  scenarioAnalysisTitle: string;
  exploreFinancialScenarios: string;
  financialEducation: string;
  learnFinancialConcepts: string;
  readyToBeBuilt: string;
  getContinuePrompting: string;
  letsBuildThis: string;

  // 404 Page
  pageNotFound: string;
  oopsPageNotFound: string;
  pageNotExist: string;
  backToDashboard: string;

  // Language Switcher
  language: string;
  selectLanguage: string;
}

export const translations: Record<Language, TranslationsType> = {
  // Hebrew
  he: {
    // Navigation
    dashboard: "דשבורד",
    income: "הכנסות",
    expenses: "הוצאות",
    savings: "חסכונות",
    investments: "השקעות",
    crypto: "קריפטו",
    goals: "יעדים",
    family: "משפחה",
    advisor: "יועץ",
    scenarioAnalysis: "ניתוח תרחישים",
    education: "חינוך",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "סקירת כלכלית",
    trackIncomeExpenses: "עקוב אחרי ההכנסות, ההוצאות והיעדים הכלכליים שלך",
    totalIncome: "סך הכנסות",
    totalExpenses: "סך הוצאות",
    currentBalance: "יתרה נוכחית",
    savingsGoal: "יעד חסכונות",
    incomeVsExpenses: "הכנסות מול הוצאות",
    expenseBreakdown: "פירוט הוצאות",
    balanceTrend: "מגמת יתרה",
    recentTransactions: "עסקאות אחרונות",

    // Dashboard Cards
    up: "עלייה",
    down: "ירידה",
    completed: "הושלם",

    // Table Headers
    description: "תיאור",
    date: "תאריך",
    amount: "סכום",
    status: "סטטוס",
    source: "מקור",

    // Income Page
    incomeManagement: "ניהול הכנסות",
    trackIncomeStreams: "עקוב אחרי כל מקורות ההכנסה שלך",
    totalMonthlyIncome: "סך הכנסות חודשיות",
    incomeStreams: "מקורות הכנסה",
    averageMonthly: "ממוצע חודשי",
    activeIncomeStreams: "מקורות הכנסה פעילים",
    frequency: "תדירות",
    next: "הבא",
    addIncomeStream: "הוסף מקור הכנסה",
    regular: "קבוע",
    variable: "משתנה",
    incomeHistory: "היסטוריית הכנסות",
    received: "התקבל",

    // Transaction Types
    salaryDeposit: "הפקדת משכורת",
    groceryShopping: "קניות מכולת",
    gymMembership: "כושר",
    freelancePayment: "תשלום עצמאי",
    electricBill: "חשמל",
    freelanceProjects: "פרויקטים עצמאיים",
    investmentsDividend: "דיבידנד השקעות",
    sideHustle: "עבודה צדדית",

    // Placeholder Pages
    expenseTracking: "מעקב הוצאות",
    monitorManageExpenses: "עקוב אחרי וניהל את כל ההוצאות שלך במקום אחד",
    savingsGoalsTitle: "יעדי חסכונות",
    setTrackGoals: "קבע ועקוב אחרי יעדי חסכונות קצרי וארוכי טווח",
    investmentPortfolio: "תיק השקעות",
    trackStocksBonds: "עקוב אחרי מניות, אג״ח ונכסים השקעה אחרים",
    cryptoHoldings: "אחזקות קריפטו",
    monitorCryptoPortfolio: "עקוב אחרי תיק הקריפטו שלך וגלישת שוק",
    financialGoalsTitle: "יעדים כלכליים",
    createManageGoals: "צור וניהל יעדים כלכליים קצרי וארוכי טווח",
    familyFinance: "כלכלת משפחה",
    manageFamilyBudgets: "נהל כלכלה משפחתית ותקציבים משותפים",
    financialAdvisor: "יועץ כלכלי",
    getPersonalizedAdvice: "קבל עצות כלכליות ותוצאות מותאמות אישית",
    scenarioAnalysisTitle: "ניתוח תרחישים",
    exploreFinancialScenarios: "חקור תרחישים כלכליים שונים ותוצאותיהם",
    financialEducation: "השכלה כלכלית",
    learnFinancialConcepts: "למד קונספטים כלכליים ועקרונות טובים",
    readyToBeBuilt: "דף זה מוכן להיבנות עם התוכן המותאם שלך.",
    getContinuePrompting: "התחל בכך שתציין אילו תכונות ותוכן אתה רוצה לראות בדף זה.",
    letsBuildThis: "בואו נבנה את זה",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "אופס! העמוד לא נמצא",
    pageNotExist: "העמוד שאתה מחפש לא קיים או הועבר.",
    backToDashboard: "חזור לדשבורד",

    // Language Switcher
    language: "שפה",
    selectLanguage: "בחר שפה",
  },

  // English
  en: {
    // Navigation
    dashboard: "Dashboard",
    income: "Income",
    expenses: "Expenses",
    savings: "Savings",
    investments: "Investments",
    crypto: "Crypto",
    goals: "Goals",
    family: "Family",
    advisor: "Advisor",
    scenarioAnalysis: "Scenario Analysis",
    education: "Education",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "Financial Overview",
    trackIncomeExpenses: "Track your income, expenses, and financial goals",
    totalIncome: "Total Income",
    totalExpenses: "Total Expenses",
    currentBalance: "Current Balance",
    savingsGoal: "Savings Goal",
    incomeVsExpenses: "Income vs Expenses",
    expenseBreakdown: "Expense Breakdown",
    balanceTrend: "Balance Trend",
    recentTransactions: "Recent Transactions",

    // Dashboard Cards
    up: "Up",
    down: "Down",
    completed: "Completed",

    // Table Headers
    description: "Description",
    date: "Date",
    amount: "Amount",
    status: "Status",
    source: "Source",

    // Income Page
    incomeManagement: "Income Management",
    trackIncomeStreams: "Track all your income sources and streams",
    totalMonthlyIncome: "Total Monthly Income",
    incomeStreams: "Income Streams",
    averageMonthly: "Average Monthly",
    activeIncomeStreams: "Active Income Streams",
    frequency: "Frequency",
    next: "Next",
    addIncomeStream: "Add Income Stream",
    regular: "Regular",
    variable: "Variable",
    incomeHistory: "Income History",
    received: "Received",

    // Transaction Types
    salaryDeposit: "Salary Deposit",
    groceryShopping: "Grocery Shopping",
    gymMembership: "Gym Membership",
    freelancePayment: "Freelance Payment",
    electricBill: "Electric Bill",
    freelanceProjects: "Freelance Projects",
    investmentsDividend: "Investments Dividend",
    sideHustle: "Side Hustle",

    // Placeholder Pages
    expenseTracking: "Expense Tracking",
    monitorManageExpenses: "Monitor and manage all your expenses in one place",
    savingsGoalsTitle: "Savings Goals",
    setTrackGoals: "Set and track your savings goals with progress tracking",
    investmentPortfolio: "Investment Portfolio",
    trackStocksBonds: "Track your stocks, bonds, and other investment assets",
    cryptoHoldings: "Cryptocurrency Holdings",
    monitorCryptoPortfolio: "Monitor your crypto portfolio and track market movements",
    financialGoalsTitle: "Financial Goals",
    createManageGoals: "Create and manage your short and long-term financial goals",
    familyFinance: "Family Finance",
    manageFamilyBudgets: "Manage family finances and shared budgets",
    financialAdvisor: "Financial Advisor",
    getPersonalizedAdvice: "Get personalized financial advice and recommendations",
    scenarioAnalysisTitle: "Scenario Analysis",
    exploreFinancialScenarios: "Explore different financial scenarios and their outcomes",
    financialEducation: "Financial Education",
    learnFinancialConcepts: "Learn financial concepts and best practices",
    readyToBeBuilt: "This page is ready to be built out with your custom content.",
    getContinuePrompting: "Get started by specifying what features and content you'd like to see on this page.",
    letsBuildThis: "Let's Build This",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "Oops! Page not found",
    pageNotExist: "The page you're looking for doesn't exist or has been moved.",
    backToDashboard: "Back to Dashboard",

    // Language Switcher
    language: "Language",
    selectLanguage: "Select Language",
  },

  // Simplified Chinese
  zh: {
    // Navigation
    dashboard: "仪表板",
    income: "收入",
    expenses: "支出",
    savings: "储蓄",
    investments: "投资",
    crypto: "加密货币",
    goals: "目标",
    family: "家庭",
    advisor: "顾问",
    scenarioAnalysis: "场景分析",
    education: "教育",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "财务概览",
    trackIncomeExpenses: "跟踪您的收入、支出和财务目标",
    totalIncome: "总收入",
    totalExpenses: "总支出",
    currentBalance: "当前余额",
    savingsGoal: "储蓄目标",
    incomeVsExpenses: "收入与支出",
    expenseBreakdown: "支出明细",
    balanceTrend: "余额趋势",
    recentTransactions: "最近交易",

    // Dashboard Cards
    up: "上升",
    down: "下降",
    completed: "已完成",

    // Table Headers
    description: "描述",
    date: "日期",
    amount: "金额",
    status: "状态",
    source: "来源",

    // Income Page
    incomeManagement: "收入管理",
    trackIncomeStreams: "跟踪所有收入来源",
    totalMonthlyIncome: "月总收入",
    incomeStreams: "收入来源",
    averageMonthly: "平均月收入",
    activeIncomeStreams: "活跃收入来源",
    frequency: "频率",
    next: "下一个",
    addIncomeStream: "添加收入来源",
    regular: "定期",
    variable: "可变",
    incomeHistory: "收入历史",
    received: "已收到",

    // Transaction Types
    salaryDeposit: "工资存入",
    groceryShopping: "杂货购物",
    gymMembership: "健身房会员",
    freelancePayment: "自由职业者付款",
    electricBill: "电费",
    freelanceProjects: "自由职业项目",
    investmentsDividend: "投资股息",
    sideHustle: "副业",

    // Placeholder Pages
    expenseTracking: "支出跟踪",
    monitorManageExpenses: "在一个地方监控和管理所有支出",
    savingsGoalsTitle: "储蓄目标",
    setTrackGoals: "设定和跟踪您的储蓄目标并跟进进展",
    investmentPortfolio: "投资组合",
    trackStocksBonds: "跟踪您的股票、债券和其他投资资产",
    cryptoHoldings: "加密货币持有",
    monitorCryptoPortfolio: "监控您的加密货币组合并跟踪市场动向",
    financialGoalsTitle: "财务目标",
    createManageGoals: "创建和管理您的短期和长期财务目标",
    familyFinance: "家庭财务",
    manageFamilyBudgets: "管理家庭财务和共享预算",
    financialAdvisor: "财务顾问",
    getPersonalizedAdvice: "获取个性化财务建议和推荐",
    scenarioAnalysisTitle: "场景分析",
    exploreFinancialScenarios: "探索不同的财务场景及其结果",
    financialEducation: "财务教育",
    learnFinancialConcepts: "学习财务概念和最佳实践",
    readyToBeBuilt: "此页面已准备好使用您的自定义内容进行构建。",
    getContinuePrompting: "通过指定您想在此页面上看到的功能和内容来开始。",
    letsBuildThis: "让我们构建这个",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "哎呀！页面未找到",
    pageNotExist: "您要查找的页面不存在或已被移动。",
    backToDashboard: "返回仪表板",

    // Language Switcher
    language: "语言",
    selectLanguage: "选择语言",
  },

  // Japanese
  ja: {
    // Navigation
    dashboard: "ダッシュボード",
    income: "収入",
    expenses: "支出",
    savings: "貯蓄",
    investments: "投資",
    crypto: "暗号資産",
    goals: "目標",
    family: "ファミリー",
    advisor: "アドバイザー",
    scenarioAnalysis: "シナリオ分析",
    education: "教育",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "財務概要",
    trackIncomeExpenses: "収入、支出、財務目標を追跡します",
    totalIncome: "総収入",
    totalExpenses: "総支出",
    currentBalance: "現在の残高",
    savingsGoal: "貯蓄目標",
    incomeVsExpenses: "収入対支出",
    expenseBreakdown: "支出の内訳",
    balanceTrend: "残高トレンド",
    recentTransactions: "最近のトランザクション",

    // Dashboard Cards
    up: "上昇",
    down: "下降",
    completed: "完成",

    // Table Headers
    description: "説明",
    date: "日付",
    amount: "金額",
    status: "ステータス",
    source: "ソース",

    // Income Page
    incomeManagement: "収入管理",
    trackIncomeStreams: "すべての収入源を追跡します",
    totalMonthlyIncome: "月収合計",
    incomeStreams: "収入源",
    averageMonthly: "平均月額",
    activeIncomeStreams: "アクティブな収入源",
    frequency: "頻度",
    next: "次へ",
    addIncomeStream: "収入源を追加",
    regular: "通常",
    variable: "可変",
    incomeHistory: "収入履歴",
    received: "受け取り",

    // Transaction Types
    salaryDeposit: "給与振込",
    groceryShopping: "食料品の買い物",
    gymMembership: "ジム会費",
    freelancePayment: "フリーランス報酬",
    electricBill: "電気代",
    freelanceProjects: "フリーランスプロジェクト",
    investmentsDividend: "投資配当",
    sideHustle: "副業",

    // Placeholder Pages
    expenseTracking: "支出追跡",
    monitorManageExpenses: "すべての支出を1か所で監視および管理します",
    savingsGoalsTitle: "貯蓄目標",
    setTrackGoals: "貯蓄目標を設定し、進捗を追跡します",
    investmentPortfolio: "投資ポートフォリオ",
    trackStocksBonds: "株、債券、その他の投資資産を追跡します",
    cryptoHoldings: "暗号資産の保有",
    monitorCryptoPortfolio: "暗号資産ポートフォリオを監視し、市場動向を追跡します",
    financialGoalsTitle: "財務目標",
    createManageGoals: "短期および長期の財務目標を作成および管理します",
    familyFinance: "家族の財務",
    manageFamilyBudgets: "家族の財務と共有予算を管理します",
    financialAdvisor: "財務アドバイザー",
    getPersonalizedAdvice: "パーソナライズされた財務アドバイスと推奨事項を取得します",
    scenarioAnalysisTitle: "シナリオ分析",
    exploreFinancialScenarios: "さまざまな財務シナリオとその結果を探索します",
    financialEducation: "財務教育",
    learnFinancialConcepts: "財務概念とベストプラクティスを学ぶ",
    readyToBeBuilt: "このページはカスタムコンテンツで構築する準備ができています。",
    getContinuePrompting: "このページに表示したい機能とコンテンツを指定することで始めます。",
    letsBuildThis: "これを構築しましょう",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "申し訳ございません。ページが見つかりません",
    pageNotExist: "お探しのページは存在しないか、移動されています。",
    backToDashboard: "ダッシュボードに戻る",

    // Language Switcher
    language: "言語",
    selectLanguage: "言語を選択",
  },

  // French
  fr: {
    // Navigation
    dashboard: "Tableau de bord",
    income: "Revenus",
    expenses: "Dépenses",
    savings: "Épargne",
    investments: "Investissements",
    crypto: "Crypto-monnaie",
    goals: "Objectifs",
    family: "Famille",
    advisor: "Conseiller",
    scenarioAnalysis: "Analyse de scénarios",
    education: "Éducation",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "Aperçu financier",
    trackIncomeExpenses: "Suivez vos revenus, dépenses et objectifs financiers",
    totalIncome: "Revenu total",
    totalExpenses: "Dépenses totales",
    currentBalance: "Solde actuel",
    savingsGoal: "Objectif d'épargne",
    incomeVsExpenses: "Revenus vs Dépenses",
    expenseBreakdown: "Ventilation des dépenses",
    balanceTrend: "Tendance du solde",
    recentTransactions: "Transactions récentes",

    // Dashboard Cards
    up: "Augmentation",
    down: "Diminution",
    completed: "Complété",

    // Table Headers
    description: "Description",
    date: "Date",
    amount: "Montant",
    status: "Statut",
    source: "Source",

    // Income Page
    incomeManagement: "Gestion des revenus",
    trackIncomeStreams: "Suivez toutes vos sources de revenus",
    totalMonthlyIncome: "Revenu mensuel total",
    incomeStreams: "Sources de revenus",
    averageMonthly: "Moyenne mensuelle",
    activeIncomeStreams: "Sources de revenus actives",
    frequency: "Fréquence",
    next: "Suivant",
    addIncomeStream: "Ajouter une source de revenu",
    regular: "Régulier",
    variable: "Variable",
    incomeHistory: "Historique des revenus",
    received: "Reçu",

    // Transaction Types
    salaryDeposit: "Dépôt de salaire",
    groceryShopping: "Achats d'épicerie",
    gymMembership: "Adhésion à la salle de sport",
    freelancePayment: "Paiement en tant qu'indépendant",
    electricBill: "Facture d'électricité",
    freelanceProjects: "Projets en tant qu'indépendant",
    investmentsDividend: "Dividende d'investissements",
    sideHustle: "Activité secondaire",

    // Placeholder Pages
    expenseTracking: "Suivi des dépenses",
    monitorManageExpenses: "Surveillez et gérez toutes vos dépenses en un seul endroit",
    savingsGoalsTitle: "Objectifs d'épargne",
    setTrackGoals: "Définissez et suivez vos objectifs d'épargne avec suivi des progrès",
    investmentPortfolio: "Portefeuille d'investissements",
    trackStocksBonds: "Suivez vos actions, obligations et autres actifs d'investissement",
    cryptoHoldings: "Avoirs en crypto-monnaie",
    monitorCryptoPortfolio: "Surveillez votre portefeuille crypto et les mouvements du marché",
    financialGoalsTitle: "Objectifs financiers",
    createManageGoals: "Créez et gérez vos objectifs financiers à court et long terme",
    familyFinance: "Finances familiales",
    manageFamilyBudgets: "Gérez les finances familiales et les budgets partagés",
    financialAdvisor: "Conseiller financier",
    getPersonalizedAdvice: "Obtenez des conseils financiers et des recommandations personnalisés",
    scenarioAnalysisTitle: "Analyse de scénarios",
    exploreFinancialScenarios: "Explorez différents scénarios financiers et leurs résultats",
    financialEducation: "Éducation financière",
    learnFinancialConcepts: "Apprenez les concepts financiers et les meilleures pratiques",
    readyToBeBuilt: "Cette page est prête à être construite avec votre contenu personnalisé.",
    getContinuePrompting: "Commencez par spécifier les fonctionnalités et le contenu que vous souhaitez voir sur cette page.",
    letsBuildThis: "Construisons ceci",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "Oups ! Page non trouvée",
    pageNotExist: "La page que vous recherchez n'existe pas ou a été déplacée.",
    backToDashboard: "Retour au tableau de bord",

    // Language Switcher
    language: "Langue",
    selectLanguage: "Sélectionner la langue",
  },

  // Hindi
  hi: {
    // Navigation
    dashboard: "डैशबोर्ड",
    income: "आय",
    expenses: "व्यय",
    savings: "बचत",
    investments: "निवेश",
    crypto: "क्रिप्टो",
    goals: "लक्ष्य",
    family: "परिवार",
    advisor: "सलाहकार",
    scenarioAnalysis: "परिदृश्य विश्लेषण",
    education: "शिक्षा",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "वित्तीय सारांश",
    trackIncomeExpenses: "अपनी आय, व्यय और वित्तीय लक्ष्यों को ट्रैक करें",
    totalIncome: "कुल आय",
    totalExpenses: "कुल व्यय",
    currentBalance: "वर्तमान शेष",
    savingsGoal: "बचत लक्ष्य",
    incomeVsExpenses: "आय बनाम व्यय",
    expenseBreakdown: "व्यय का विवरण",
    balanceTrend: "शेष प्रवृत्ति",
    recentTransactions: "हाल के लेनदेन",

    // Dashboard Cards
    up: "ऊपर",
    down: "नीचे",
    completed: "पूर्ण",

    // Table Headers
    description: "विवरण",
    date: "तारीख",
    amount: "राशि",
    status: "स्थिति",
    source: "स्रोत",

    // Income Page
    incomeManagement: "आय प्रबंधन",
    trackIncomeStreams: "अपने सभी आय स्रोतों को ट्रैक करें",
    totalMonthlyIncome: "कुल मासिक आय",
    incomeStreams: "आय स्रोत",
    averageMonthly: "औसत मासिक",
    activeIncomeStreams: "सक्रिय आय स्रोत",
    frequency: "आवृत्ति",
    next: "अगला",
    addIncomeStream: "आय स्रोत जोड़ें",
    regular: "नियमित",
    variable: "परिवर्तनशील",
    incomeHistory: "आय इतिहास",
    received: "प्राप्त",

    // Transaction Types
    salaryDeposit: "वेतन जमा",
    groceryShopping: "किराने की खरीदारी",
    gymMembership: "जिम सदस्यता",
    freelancePayment: "फ्रीलांस भुगतान",
    electricBill: "बिजली बिल",
    freelanceProjects: "फ्रीलांस परियोजनाएं",
    investmentsDividend: "निवेश लाभांश",
    sideHustle: "साइड हसल",

    // Placeholder Pages
    expenseTracking: "व्यय ट्रैकिंग",
    monitorManageExpenses: "अपने सभी व्यय को एक जगह पर निगरानी करें और प्रबंधित करें",
    savingsGoalsTitle: "बचत लक्ष्य",
    setTrackGoals: "अपने बचत लक्ष्यों को सेट करें और प्रगति को ट्रैक करें",
    investmentPortfolio: "निवेश पोर्टफोलियो",
    trackStocksBonds: "अपने स्टॉक, बॉन्ड और अन्य निवेश संपत्ति को ट्रैक करें",
    cryptoHoldings: "क्रिप्टो होल्डिंग्स",
    monitorCryptoPortfolio: "अपने क्रिप्टो पोर्टफोलियो की निगरानी करें और बाजार आंदोलनों को ट्रैक करें",
    financialGoalsTitle: "वित्तीय लक्ष्य",
    createManageGoals: "अपने अल्पकालीन और दीर्घकालीन वित्तीय लक्ष्यों को बनाएं और प्रबंधित करें",
    familyFinance: "पारिवारिक वित्त",
    manageFamilyBudgets: "पारिवारिक वित्त और साझा बजट प्रबंधित करें",
    financialAdvisor: "वित्तीय सलाहकार",
    getPersonalizedAdvice: "व्यक्तिगत वित्तीय सलाह और सिफारिशें प्राप्त करें",
    scenarioAnalysisTitle: "परिदृश्य विश्लेषण",
    exploreFinancialScenarios: "विभिन्न वित्तीय परिदृश्यों और उनके परिणामों का पता लगाएं",
    financialEducation: "वित्तीय शिक्षा",
    learnFinancialConcepts: "वित्तीय अवधारणाएं और सर्वोत्तम प्रथाएं सीखें",
    readyToBeBuilt: "यह पृष्ठ आपकी कस्टम सामग्री के साथ बनाने के लिए तैयार है।",
    getContinuePrompting: "इस पृष्ठ पर देखना चाहते हैं ऐसी सुविधाओं और सामग्री को निर्दिष्ट करके शुरू करें।",
    letsBuildThis: "आइए इसे बनाते हैं",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "अफसोस! पृष्ठ नहीं मिला",
    pageNotExist: "आप जो पृष्ठ ढूंढ रहे हैं वह मौजूद नहीं है या स्थानांतरित किया गया है।",
    backToDashboard: "डैशबोर्ड पर वापस जाएं",

    // Language Switcher
    language: "भाषा",
    selectLanguage: "भाषा चुनें",
  },

  // Spanish
  es: {
    // Navigation
    dashboard: "Panel de control",
    income: "Ingresos",
    expenses: "Gastos",
    savings: "Ahorros",
    investments: "Inversiones",
    crypto: "Criptomoneda",
    goals: "Objetivos",
    family: "Familia",
    advisor: "Asesor",
    scenarioAnalysis: "Análisis de escenarios",
    education: "Educación",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "Descripción financiera",
    trackIncomeExpenses: "Realiza un seguimiento de tus ingresos, gastos y objetivos financieros",
    totalIncome: "Ingresos totales",
    totalExpenses: "Gastos totales",
    currentBalance: "Saldo actual",
    savingsGoal: "Objetivo de ahorro",
    incomeVsExpenses: "Ingresos vs Gastos",
    expenseBreakdown: "Desglose de gastos",
    balanceTrend: "Tendencia de saldo",
    recentTransactions: "Transacciones recientes",

    // Dashboard Cards
    up: "Arriba",
    down: "Abajo",
    completed: "Completado",

    // Table Headers
    description: "Descripción",
    date: "Fecha",
    amount: "Cantidad",
    status: "Estado",
    source: "Fuente",

    // Income Page
    incomeManagement: "Gestión de ingresos",
    trackIncomeStreams: "Realiza un seguimiento de todas tus fuentes de ingresos",
    totalMonthlyIncome: "Ingreso mensual total",
    incomeStreams: "Fuentes de ingresos",
    averageMonthly: "Promedio mensual",
    activeIncomeStreams: "Fuentes de ingresos activas",
    frequency: "Frecuencia",
    next: "Siguiente",
    addIncomeStream: "Agregar fuente de ingresos",
    regular: "Regular",
    variable: "Variable",
    incomeHistory: "Historial de ingresos",
    received: "Recibido",

    // Transaction Types
    salaryDeposit: "Depósito de salario",
    groceryShopping: "Compras de abarrotes",
    gymMembership: "Membresía de gimnasio",
    freelancePayment: "Pago de autónomo",
    electricBill: "Factura de electricidad",
    freelanceProjects: "Proyectos de autónomo",
    investmentsDividend: "Dividendo de inversiones",
    sideHustle: "Negocio adicional",

    // Placeholder Pages
    expenseTracking: "Seguimiento de gastos",
    monitorManageExpenses: "Monitorea y gestiona todos tus gastos en un solo lugar",
    savingsGoalsTitle: "Objetivos de ahorro",
    setTrackGoals: "Establece y realiza un seguimiento de tus objetivos de ahorro",
    investmentPortfolio: "Cartera de inversiones",
    trackStocksBonds: "Realiza un seguimiento de tus acciones, bonos y otros activos de inversión",
    cryptoHoldings: "Tenencias de criptomonedas",
    monitorCryptoPortfolio: "Monitorea tu cartera de criptomonedas y los movimientos del mercado",
    financialGoalsTitle: "Objetivos financieros",
    createManageGoals: "Crea y gestiona tus objetivos financieros a corto y largo plazo",
    familyFinance: "Finanzas familiares",
    manageFamilyBudgets: "Gestiona las finanzas familiares y presupuestos compartidos",
    financialAdvisor: "Asesor financiero",
    getPersonalizedAdvice: "Obtén asesoramiento financiero personalizado y recomendaciones",
    scenarioAnalysisTitle: "Análisis de escenarios",
    exploreFinancialScenarios: "Explora diferentes escenarios financieros y sus resultados",
    financialEducation: "Educación financiera",
    learnFinancialConcepts: "Aprende conceptos financieros y mejores prácticas",
    readyToBeBuilt: "Esta página está lista para ser construida con tu contenido personalizado.",
    getContinuePrompting: "Comienza especificando qué características y contenido te gustaría ver en esta página.",
    letsBuildThis: "Construyamos esto",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "¡Oops! Página no encontrada",
    pageNotExist: "La página que buscas no existe o ha sido movida.",
    backToDashboard: "Volver al panel de control",

    // Language Switcher
    language: "Idioma",
    selectLanguage: "Seleccionar idioma",
  },

  // German
  de: {
    // Navigation
    dashboard: "Dashboard",
    income: "Einkommen",
    expenses: "Ausgaben",
    savings: "Ersparnisse",
    investments: "Investitionen",
    crypto: "Kryptowährung",
    goals: "Ziele",
    family: "Familie",
    advisor: "Berater",
    scenarioAnalysis: "Szenarioanalyse",
    education: "Bildung",

    // App Name
    appName: "FinanceFlow",
    copyright: "© 2024 FinanceFlow",

    // Dashboard Page
    financialOverview: "Finanzübersicht",
    trackIncomeExpenses: "Verfolge dein Einkommen, deine Ausgaben und deine finanziellen Ziele",
    totalIncome: "Gesamteinkommen",
    totalExpenses: "Gesamtausgaben",
    currentBalance: "Aktueller Saldo",
    savingsGoal: "Sparziel",
    incomeVsExpenses: "Einkommen vs. Ausgaben",
    expenseBreakdown: "Ausgabenaufschlüsselung",
    balanceTrend: "Saldotrend",
    recentTransactions: "Letzte Transaktionen",

    // Dashboard Cards
    up: "Oben",
    down: "Unten",
    completed: "Abgeschlossen",

    // Table Headers
    description: "Beschreibung",
    date: "Datum",
    amount: "Betrag",
    status: "Status",
    source: "Quelle",

    // Income Page
    incomeManagement: "Einkommensverwaltung",
    trackIncomeStreams: "Verfolge alle deine Einkommensquellen",
    totalMonthlyIncome: "Gesamtmonatliches Einkommen",
    incomeStreams: "Einkommensquellen",
    averageMonthly: "Durchschnittlich monatlich",
    activeIncomeStreams: "Aktive Einkommensquellen",
    frequency: "Häufigkeit",
    next: "Weiter",
    addIncomeStream: "Einkommensquelle hinzufügen",
    regular: "Regulär",
    variable: "Variabel",
    incomeHistory: "Einkommensverlauf",
    received: "Erhalten",

    // Transaction Types
    salaryDeposit: "Gehaltshinterlegung",
    groceryShopping: "Lebensmittel einkaufen",
    gymMembership: "Fitnessstudio-Mitgliedschaft",
    freelancePayment: "Freiberufler-Zahlung",
    electricBill: "Stromrechnung",
    freelanceProjects: "Freiberufler-Projekte",
    investmentsDividend: "Anlagedividende",
    sideHustle: "Nebeneinkommen",

    // Placeholder Pages
    expenseTracking: "Ausgabenverfolgung",
    monitorManageExpenses: "Überwache und verwalte alle deine Ausgaben an einem Ort",
    savingsGoalsTitle: "Sparziele",
    setTrackGoals: "Lege Sparziele fest und verfolge deine Fortschritte",
    investmentPortfolio: "Anlageportfolio",
    trackStocksBonds: "Verfolge deine Aktien, Anleihen und andere Anlagevermögenswerte",
    cryptoHoldings: "Kryptowährungsbestände",
    monitorCryptoPortfolio: "Überwache dein Kryptowährungsportfolio und Marktbewegungen",
    financialGoalsTitle: "Finanzielle Ziele",
    createManageGoals: "Erstelle und verwalte deine kurz- und langfristigen Finanzziele",
    familyFinance: "Familienfinanzen",
    manageFamilyBudgets: "Verwalte Familienfinanzen und gemeinsame Budgets",
    financialAdvisor: "Finanzberater",
    getPersonalizedAdvice: "Erhalten Sie personalisierte Finanzberatung und Empfehlungen",
    scenarioAnalysisTitle: "Szenarioanalyse",
    exploreFinancialScenarios: "Erkunde verschiedene Finanzszenarien und deren Ergebnisse",
    financialEducation: "Finanzielle Bildung",
    learnFinancialConcepts: "Lerne Finanzkonzepte und Best Practices",
    readyToBeBuilt: "Diese Seite ist bereit, mit deinem benutzerdefinierten Inhalt erstellt zu werden.",
    getContinuePrompting: "Geben Sie zunächst an, welche Funktionen und Inhalte Sie auf dieser Seite sehen möchten.",
    letsBuildThis: "Lass uns das aufbauen",

    // 404 Page
    pageNotFound: "404",
    oopsPageNotFound: "Hoppla! Seite nicht gefunden",
    pageNotExist: "Die gesuchte Seite existiert nicht oder wurde verschoben.",
    backToDashboard: "Zurück zum Dashboard",

    // Language Switcher
    language: "Sprache",
    selectLanguage: "Sprache wählen",
  },
};

export const getTranslation = (language: Language, key: keyof TranslationsType): string => {
  return translations[language]?.[key] || translations.en[key] || "";
};
