import Layout from "@/components/Layout";
import { Brain } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function ScenarioAnalysis() {
  return (
    <PlaceholderPage
      title="Scenario Analysis"
      description="Explore different financial scenarios and their outcomes"
      icon={Brain}
    />
  );
}
