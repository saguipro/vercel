import Layout from "@/components/Layout";
import { PiggyBank } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Savings() {
  return (
    <PlaceholderPage
      title="Savings Goals"
      description="Set and track your savings goals with progress tracking"
      icon={PiggyBank}
    />
  );
}
