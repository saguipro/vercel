import Layout from "@/components/Layout";
import { BookOpen } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Education() {
  return (
    <PlaceholderPage
      title="Financial Education"
      description="Learn financial concepts and best practices"
      icon={BookOpen}
    />
  );
}
