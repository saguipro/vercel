import Layout from "@/components/Layout";
import { TrendingDown, Plus, Filter } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Expenses() {
  return (
    <PlaceholderPage
      title="Expense Tracking"
      description="Monitor and manage all your expenses in one place"
      icon={TrendingDown}
    />
  );
}
