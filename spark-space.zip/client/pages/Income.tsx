import Layout from "@/components/Layout";
import {
  TrendingUp,
  Plus,
  MoreVertical,
  Calendar,
  DollarSign,
} from "lucide-react";
import { useTranslation } from "@/hooks/useTranslation";

const getIncomeStreams = (t: (key: string) => string) => [
  {
    id: 1,
    name: t("income"),
    amount: 5000,
    frequency: t("frequency"),
    nextPayment: "2024-02-01",
    type: "regular",
  },
  {
    id: 2,
    name: t("freelanceProjects"),
    amount: 1200,
    frequency: "Variable",
    nextPayment: "TBD",
    type: "variable",
  },
  {
    id: 3,
    name: t("investmentsDividend"),
    amount: 250,
    frequency: "Quarterly",
    nextPayment: "2024-03-15",
    type: "regular",
  },
  {
    id: 4,
    name: t("sideHustle"),
    amount: 400,
    frequency: "Monthly",
    nextPayment: "2024-02-05",
    type: "regular",
  },
];

const getIncomeHistory = (t: (key: string) => string) => [
  {
    id: 1,
    source: t("income"),
    amount: 5000,
    date: "2024-01-01",
    status: t("received"),
  },
  {
    id: 2,
    source: t("freelanceProjects"),
    amount: 800,
    date: "2023-12-28",
    status: t("received"),
  },
  {
    id: 3,
    source: t("investmentsDividend"),
    amount: 250,
    date: "2023-12-15",
    status: t("received"),
  },
  {
    id: 4,
    source: t("sideHustle"),
    amount: 400,
    date: "2023-12-10",
    status: t("received"),
  },
  {
    id: 5,
    source: t("income"),
    amount: 5000,
    date: "2023-12-01",
    status: t("received"),
  },
];

export default function Income() {
  const { t } = useTranslation();
  const incomeStreams = getIncomeStreams(t);
  const incomeHistory = getIncomeHistory(t);

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-sidebar-accent/20 p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
                {t("incomeManagement")}
              </h1>
              <p className="text-muted-foreground">
                {t("trackIncomeStreams")}
              </p>
            </div>
            <button className="mt-4 md:mt-0 flex items-center gap-2 bg-sidebar-primary text-sidebar-primary-foreground px-6 py-2 rounded-lg hover:opacity-90 transition-opacity font-medium">
              <Plus className="w-5 h-5" />
              {t("addIncomeStream")}
            </button>
          </div>

          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <SummaryCard
              label={t("totalMonthlyIncome")}
              value="$6,850"
              icon={DollarSign}
            />
            <SummaryCard
              label={t("incomeStreams")}
              value="4"
              icon={TrendingUp}
            />
            <SummaryCard
              label={t("averageMonthly")}
              value="$6,850"
              icon={Calendar}
            />
          </div>

          {/* Active Income Streams */}
          <div className="bg-card rounded-xl p-6 border border-border shadow-sm mb-8">
            <h2 className="text-lg font-semibold text-card-foreground mb-6">
              {t("activeIncomeStreams")}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {incomeStreams.map((stream) => (
                <div
                  key={stream.id}
                  className="border border-border rounded-lg p-4 hover:bg-muted/30 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="font-semibold text-foreground">
                        {stream.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {stream.frequency}
                      </p>
                    </div>
                    <button className="p-1 hover:bg-sidebar-accent rounded transition-colors">
                      <MoreVertical className="w-4 h-4 text-muted-foreground" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-2xl font-bold text-foreground">
                        ${stream.amount.toLocaleString()}
                      </span>
                      <span
                        className={`text-xs font-semibold px-2 py-1 rounded ${
                          stream.type === "regular"
                            ? "bg-green-100 text-green-700"
                            : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {stream.type === "regular"
                          ? t("regular")
                          : t("variable")}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {t("next")}: {stream.nextPayment}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Income History */}
          <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
            <h2 className="text-lg font-semibold text-card-foreground mb-4">
              {t("incomeHistory")}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("source")}
                    </th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("date")}
                    </th>
                    <th className="text-right py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("amount")}
                    </th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("status")}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {incomeHistory.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-border hover:bg-muted/50 transition-colors"
                    >
                      <td className="py-3 px-4 font-medium text-foreground">
                        {item.source}
                      </td>
                      <td className="py-3 px-4 text-muted-foreground text-sm">
                        {item.date}
                      </td>
                      <td className="py-3 px-4 text-right font-semibold text-green-600">
                        +${item.amount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-block bg-green-100 text-green-700 text-xs font-semibold px-3 py-1 rounded-full">
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

interface SummaryCardProps {
  label: string;
  value: string;
  icon: React.ComponentType<{ className: string }>;
}

function SummaryCard({ label, value, icon: Icon }: SummaryCardProps) {
  return (
    <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-lg bg-sidebar-accent flex items-center justify-center">
          <Icon className="w-6 h-6 text-sidebar-primary" />
        </div>
        <div>
          <p className="text-muted-foreground text-sm">{label}</p>
          <p className="text-2xl font-bold text-card-foreground">{value}</p>
        </div>
      </div>
    </div>
  );
}
