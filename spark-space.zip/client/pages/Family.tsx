import Layout from "@/components/Layout";
import { Users } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Family() {
  return (
    <PlaceholderPage
      title="Family Finance"
      description="Manage family finances and shared budgets"
      icon={Users}
    />
  );
}
