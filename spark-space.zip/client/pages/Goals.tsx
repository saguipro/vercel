import Layout from "@/components/Layout";
import { Target } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Goals() {
  return (
    <PlaceholderPage
      title="Financial Goals"
      description="Create and manage your short and long-term financial goals"
      icon={Target}
    />
  );
}
