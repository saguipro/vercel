import Layout from "@/components/Layout";
import { Lightbulb } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Advisor() {
  return (
    <PlaceholderPage
      title="Financial Advisor"
      description="Get personalized financial advice and recommendations"
      icon={Lightbulb}
    />
  );
}
