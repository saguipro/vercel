import Layout from "@/components/Layout";
import { Briefcase } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Investments() {
  return (
    <PlaceholderPage
      title="Investment Portfolio"
      description="Track your stocks, bonds, and other investment assets"
      icon={Briefcase}
    />
  );
}
