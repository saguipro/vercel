import Layout from "@/components/Layout";
import {
  TrendingUp,
  TrendingDown,
  Wallet,
  PiggyBank,
  ArrowUpRight,
  ArrowDownLeft,
} from "lucide-react";
import { useState, useEffect } from "react";
import { useTranslation } from "@/hooks/useTranslation";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const monthlyData = [
  { month: "Jan", income: 4000, expenses: 2400 },
  { month: "Feb", income: 3000, expenses: 1398 },
  { month: "Mar", income: 2000, expenses: 9800 },
  { month: "Apr", income: 2780, expenses: 3908 },
  { month: "May", income: 1890, expenses: 4800 },
  { month: "Jun", income: 2390, expenses: 3800 },
  { month: "Jul", income: 3490, expenses: 4300 },
];

const expenseBreakdown = [
  { name: "Housing", value: 1200, color: "#3b82f6" },
  { name: "Food", value: 400, color: "#10b981" },
  { name: "Transport", value: 200, color: "#f59e0b" },
  { name: "Entertainment", value: 300, color: "#8b5cf6" },
  { name: "Other", value: 200, color: "#6366f1" },
];

const getRecentTransactions = (t: (key: string) => string) => [
  {
    id: 1,
    description: t("salaryDeposit"),
    amount: 5000,
    type: "income",
    date: "2024-01-15",
  },
  {
    id: 2,
    description: t("groceryShopping"),
    amount: -150,
    type: "expense",
    date: "2024-01-14",
  },
  {
    id: 3,
    description: t("gymMembership"),
    amount: -50,
    type: "expense",
    date: "2024-01-13",
  },
  {
    id: 4,
    description: t("freelancePayment"),
    amount: 800,
    type: "income",
    date: "2024-01-12",
  },
  {
    id: 5,
    description: t("electricBill"),
    amount: -120,
    type: "expense",
    date: "2024-01-11",
  },
];

// Client-side chart wrapper
function IncomeVsExpensesChart() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <div className="h-80 bg-muted rounded animate-pulse" />;
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <BarChart data={monthlyData}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="month" stroke="var(--muted-foreground)" />
        <YAxis stroke="var(--muted-foreground)" />
        <Tooltip
          contentStyle={{
            backgroundColor: "var(--background)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
          }}
        />
        <Bar dataKey="income" fill="hsl(var(--sidebar-primary))" />
        <Bar dataKey="expenses" fill="hsl(var(--destructive))" />
      </BarChart>
    </ResponsiveContainer>
  );
}

function ExpenseBreakdownChart() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <div className="h-80 bg-muted rounded animate-pulse" />;
  }

  return (
    <ResponsiveContainer width="100%" height={300}>
      <PieChart>
        <Pie
          data={expenseBreakdown}
          cx="50%"
          cy="50%"
          innerRadius={60}
          outerRadius={100}
          paddingAngle={2}
          dataKey="value"
        >
          {expenseBreakdown.map((entry) => (
            <Cell key={`cell-${entry.name}`} fill={entry.color} />
          ))}
        </Pie>
        <Tooltip />
      </PieChart>
    </ResponsiveContainer>
  );
}

function BalanceTrendChart() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return <div className="h-64 bg-muted rounded animate-pulse" />;
  }

  return (
    <ResponsiveContainer width="100%" height={250}>
      <LineChart data={monthlyData}>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
        <XAxis dataKey="month" stroke="var(--muted-foreground)" />
        <YAxis stroke="var(--muted-foreground)" />
        <Tooltip
          contentStyle={{
            backgroundColor: "var(--background)",
            border: "1px solid var(--border)",
            borderRadius: "8px",
          }}
        />
        <Line
          type="monotone"
          dataKey="income"
          stroke="hsl(var(--sidebar-primary))"
          strokeWidth={2}
          dot={{ fill: "hsl(var(--sidebar-primary))", r: 4 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}

export default function Dashboard() {
  const { t } = useTranslation();
  const recentTransactions = getRecentTransactions(t);

  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-sidebar-accent/20 p-4 md:p-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              {t("financialOverview")}
            </h1>
            <p className="text-muted-foreground">
              {t("trackIncomeExpenses")}
            </p>
          </div>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <MetricCard
              label={t("totalIncome")}
              value="$28,450"
              change="+12.5%"
              icon={TrendingUp}
              trend="up"
            />
            <MetricCard
              label={t("totalExpenses")}
              value="$12,320"
              change="-3.2%"
              icon={TrendingDown}
              trend="down"
            />
            <MetricCard
              label={t("currentBalance")}
              value="$42,680"
              change="+8.3%"
              icon={Wallet}
              trend="up"
            />
            <MetricCard
              label={t("savingsGoal")}
              value="$15,000"
              change="75% completed"
              icon={PiggyBank}
              trend="neutral"
            />
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Income vs Expenses Chart */}
            <div className="lg:col-span-2 bg-card rounded-xl p-6 border border-border shadow-sm">
              <h2 className="text-lg font-semibold text-card-foreground mb-4">
                {t("incomeVsExpenses")}
              </h2>
              <IncomeVsExpensesChart />
            </div>

            {/* Expense Breakdown */}
            <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
              <h2 className="text-lg font-semibold text-card-foreground mb-4">
                {t("expenseBreakdown")}
              </h2>
              <ExpenseBreakdownChart />
            </div>
          </div>

          {/* Trend Chart */}
          <div className="bg-card rounded-xl p-6 border border-border shadow-sm mb-8">
            <h2 className="text-lg font-semibold text-card-foreground mb-4">
              {t("balanceTrend")}
            </h2>
            <BalanceTrendChart />
          </div>

          {/* Recent Transactions */}
          <div className="bg-card rounded-xl p-6 border border-border shadow-sm">
            <h2 className="text-lg font-semibold text-card-foreground mb-4">
              {t("recentTransactions")}
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("description")}
                    </th>
                    <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("date")}
                    </th>
                    <th className="text-right py-3 px-4 font-medium text-muted-foreground text-sm">
                      {t("amount")}
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {recentTransactions.map((transaction) => (
                    <tr
                      key={transaction.id}
                      className="border-b border-border hover:bg-muted/50 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                            {transaction.type === "income" ? (
                              <ArrowDownLeft className="w-5 h-5 text-green-500" />
                            ) : (
                              <ArrowUpRight className="w-5 h-5 text-red-500" />
                            )}
                          </div>
                          <span className="font-medium text-foreground">
                            {transaction.description}
                          </span>
                        </div>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground text-sm">
                        {transaction.date}
                      </td>
                      <td
                        className={`py-3 px-4 text-right font-semibold ${
                          transaction.type === "income"
                            ? "text-green-600"
                            : "text-red-600"
                        }`}
                      >
                        {transaction.type === "income" ? "+" : ""}
                        ${Math.abs(transaction.amount).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}

interface MetricCardProps {
  label: string;
  value: string;
  change: string;
  icon: React.ComponentType<{ className: string }>;
  trend: "up" | "down" | "neutral";
}

function MetricCard({
  label,
  value,
  change,
  icon: Icon,
  trend,
}: MetricCardProps) {
  const trendColor =
    trend === "up"
      ? "text-green-600 bg-green-50"
      : trend === "down"
        ? "text-red-600 bg-red-50"
        : "text-blue-600 bg-blue-50";

  return (
    <div className="bg-card rounded-xl p-6 border border-border shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-lg bg-sidebar-accent flex items-center justify-center">
          <Icon className="w-6 h-6 text-sidebar-primary" />
        </div>
        <span className={`text-xs font-semibold px-3 py-1 rounded-full ${trendColor}`}>
          {change}
        </span>
      </div>
      <p className="text-muted-foreground text-sm mb-1">{label}</p>
      <p className="text-2xl font-bold text-card-foreground">{value}</p>
    </div>
  );
}
