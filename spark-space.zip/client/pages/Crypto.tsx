import Layout from "@/components/Layout";
import { Bitcoin } from "lucide-react";
import PlaceholderPage from "./PlaceholderPage";

export default function Crypto() {
  return (
    <PlaceholderPage
      title="Cryptocurrency Holdings"
      description="Monitor your crypto portfolio and track market movements"
      icon={Bitcoin}
    />
  );
}
