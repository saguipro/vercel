import Layout from "@/components/Layout";
import { ArrowRight } from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon: React.ComponentType<{ className: string }>;
}

export default function PlaceholderPage({
  title,
  description,
  icon: Icon,
}: PlaceholderPageProps) {
  return (
    <Layout>
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-sidebar-accent/20 p-4 md:p-8 flex items-center justify-center">
        <div className="max-w-2xl mx-auto text-center">
          <div className="w-20 h-20 rounded-2xl bg-sidebar-accent flex items-center justify-center mx-auto mb-6">
            <Icon className="w-10 h-10 text-sidebar-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-3">
            {title}
          </h1>
          <p className="text-lg text-muted-foreground mb-8 max-w-lg mx-auto">
            {description}
          </p>
          <div className="bg-card border border-border rounded-xl p-8 text-left space-y-4">
            <p className="text-foreground font-medium">
              This page is ready to be built out with your custom content.
            </p>
            <p className="text-muted-foreground">
              Get started by specifying what features and content you'd like to
              see on this page, and I'll create a fully functional, beautiful
              interface that matches the rest of your app.
            </p>
            <div className="pt-4">
              <button className="flex items-center gap-2 bg-sidebar-primary text-sidebar-primary-foreground px-6 py-2 rounded-lg hover:opacity-90 transition-opacity font-medium">
                Let's Build This
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
