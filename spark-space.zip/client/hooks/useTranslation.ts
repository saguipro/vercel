import { useContext } from "react";
import { LanguageContext } from "@/lib/LanguageContext";
import { getTranslation, TranslationsType } from "@/lib/translations";

export const useTranslation = () => {
  const context = useContext(LanguageContext);

  if (!context) {
    throw new Error("useTranslation must be used within LanguageProvider");
  }

  const t = (key: keyof TranslationsType): string => {
    return getTranslation(context.language, key);
  };

  return {
    t,
    language: context.language,
    setLanguage: context.setLanguage,
  };
};
