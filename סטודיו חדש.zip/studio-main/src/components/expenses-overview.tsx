/**
 * @file src/components/expenses-overview.tsx
 * @fileoverview This component acts as a container for the user's expense and budget data.
 * It fetches and displays lists of expense transactions, the budget manager, and the budget tracker.
 */
'use client';

import { useCollection, useFirebase, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Loader2 } from 'lucide-react';
import AddTransactionForm from './add-transaction-form';
import BudgetManager, { Budget } from './budget-manager';
import BudgetTracker from './budget-tracker';
import type { Transaction } from './financial-overview';

/**
 * A reusable component to display a list of transactions (in this case, expenses).
 *
 * @param {object} props - The component props.
 * @param {string} props.title - The title for the transaction list card.
 * @param {Transaction[] | null} props.transactions - The array of transactions to display.
 * @param {boolean} props.isLoading - Loading state for the data.
 * @param {'income' | 'expense'} props.type - The type of transactions being displayed.
 * @returns {JSX.Element} A card component with a list of transactions.
 */
const TransactionList = ({
  title,
  transactions,
  isLoading,
  type,
}: {
  title: string;
  transactions: Transaction[] | null;
  isLoading: boolean;
  type: 'income' | 'expense';
}) => {
  const total = transactions?.reduce((acc, t) => acc + t.amount, 0) || 0;
  const currencyFormatter = new Intl.NumberFormat('en-IL', {
    style: 'currency',
    currency: 'ILS',
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading && <div className="flex justify-center p-4"><Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /></div>}
        {!isLoading && (!transactions || transactions.length === 0) && (
          <p className="text-sm text-center text-muted-foreground p-4">No transactions yet.</p>
        )}
        {transactions && transactions.length > 0 && (
          <div className="space-y-4">
            <ul className="max-h-60 space-y-3 overflow-y-auto pr-2">
              {transactions.map(t => (
                <li key={t.id} className="flex items-start justify-between text-sm">
                  <div className="flex flex-col">
                    <span className="font-medium">{t.category}</span>
                    {t.description && (
                       <span className="text-xs text-muted-foreground">{t.description}</span>
                    )}
                     <span className="text-xs text-muted-foreground">{new Date(t.date + 'T00:00:00').toLocaleDateString()}</span>
                  </div>
                  <span
                    className={`font-semibold ${
                      type === 'income'
                        ? 'text-green-600'
                        : 'text-red-600'
                    }`}
                  >
                    {type === 'income' ? '+' : '-'}{currencyFormatter.format(t.amount)}
                  </span>
                </li>
              ))}
            </ul>
            <div className="flex justify-between border-t pt-2 font-bold">
              <span>Total</span>
              <span>{currencyFormatter.format(total)}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};


/**
 * The main component for displaying the user's complete expenses and budget overview.
 * It fetches expenses and budgets, and renders all related financial components.
 *
 * @returns {JSX.Element} The ExpensesOverview component.
 */
export default function ExpensesOverview() {
  const { firestore, user } = useFirebase();

  // Memoized query for user's expense documents, ordered by date descending.
  const expensesQuery = useMemoFirebase(
    () =>
      firestore && user
        ? query(collection(firestore, 'users', user.uid, 'expenses'), orderBy('date', 'desc'))
        : null,
    [firestore, user]
  );

  // Memoized query for user's budget documents.
  const budgetsQuery = useMemoFirebase(
    () =>
      firestore && user
        ? collection(firestore, 'users', user.uid, 'budgets')
        : null,
    [firestore, user]
  );

  const { data: expenses, isLoading: expensesLoading } =
    useCollection<Omit<Transaction, 'type'>>(expensesQuery);
  const { data: budgets, isLoading: budgetsLoading } = 
    useCollection<Budget>(budgetsQuery);

  // Add the 'type' property back to the fetched data for use in the TransactionList component.
  const expensesWithType: Transaction[] | null = expenses
    ? expenses.map(e => ({ ...e, type: 'expense' }))
    : null;
    
  const isLoading = expensesLoading || budgetsLoading;

  return (
    <div className="space-y-6">
      <AddTransactionForm />
      <BudgetManager budgets={budgets} isLoading={isLoading} />
      <BudgetTracker budgets={budgets} expenses={expensesWithType} isLoading={isLoading} />
      <TransactionList
          title="Expenses"
          transactions={expensesWithType}
          isLoading={isLoading}
          type="expense"
      />
    </div>
  );
}
