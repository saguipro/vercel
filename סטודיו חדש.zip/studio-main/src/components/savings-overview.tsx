/**
 * @file src/components/savings-overview.tsx
 * @fileoverview This component displays a static overview of the user's savings and assets.
 * It includes metric cards, a savings goals tracker, and an asset distribution chart.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Plus } from 'lucide-react';

function MetricCard({ title, value, currency }: { title: string; value: number; currency: string; }) {
    return (
        <Card className="text-center p-6">
            <h3 className="text-sm text-muted-foreground mb-2">{title}</h3>
            <p className="text-3xl font-bold">
                {currency}{value.toLocaleString()}
            </p>
        </Card>
    );
}

function SavingsGoalTracker() {
    const goals = [
        { name: 'Family Vacation', current: 4500, target: 10000, color: 'bg-blue-500' },
        { name: 'New Car', current: 8000, target: 35000, color: 'bg-purple-500' },
        { name: 'Home Down Payment', current: 50000, target: 150000, color: 'bg-green-500' },
    ];
    
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Savings Goals</CardTitle>
                <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Goal
                </Button>
            </CardHeader>
            <CardContent className="space-y-6">
                {goals.map((goal, index) => (
                    <div key={index}>
                        <div className="flex justify-between mb-1 text-sm">
                            <span className="font-medium">{goal.name}</span>
                            <span>₪{goal.current.toLocaleString()} / ₪{goal.target.toLocaleString()}</span>
                        </div>
                        <Progress value={(goal.current / goal.target) * 100} />
                    </div>
                ))}
            </CardContent>
        </Card>
    );
}

function AssetDistributionChart() {
    const assets = [
        { name: 'Cash & Equivalents', value: 75000, color: 'bg-blue-500' },
        { name: 'Stocks & Investments', value: 125000, color: 'bg-purple-500' },
        { name: 'Real Estate', value: 0, color: 'bg-teal-500' },
        { name: 'Cryptocurrency', value: 15000, color: 'bg-orange-500' }
    ];

    const total = assets.reduce((sum, asset) => sum + asset.value, 0);

    return (
        <Card>
            <CardHeader>
                <CardTitle>Asset Distribution</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                 {assets.map((asset, index) => (
                    <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className={`w-3 h-3 rounded-full ${asset.color}`} />
                            <span className="text-sm font-medium">{asset.name}</span>
                        </div>
                        <div className="text-sm font-semibold">
                            ₪{asset.value.toLocaleString()} ({total > 0 ? ((asset.value / total) * 100).toFixed(1) : 0}%)
                        </div>
                    </div>
                ))}
                <div className="pt-4 border-t">
                    <div className="flex justify-between font-bold text-lg">
                        <span>Total Assets</span>
                        <span>₪{total.toLocaleString()}</span>
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}


export default function SavingsOverview() {
  const savingsMetrics = {
    netWorth: 215000,
    totalSavings: 75000,
    totalAssets: 215000,
  };
    
  return (
    <div className="space-y-8">
      <section>
          <h2 className="text-2xl font-semibold mb-4">Financial Health</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <MetricCard 
                  title="Net Worth" 
                  value={savingsMetrics.netWorth}
                  currency="₪"
              />
              <MetricCard 
                  title="Total Savings" 
                  value={savingsMetrics.totalSavings}
                  currency="₪"
              />
              <MetricCard 
                  title="Total Assets" 
                  value={savingsMetrics.totalAssets}
                  currency="₪"
              />
          </div>
      </section>
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <SavingsGoalTracker />
        <AssetDistributionChart />
      </section>
    </div>
  );
}
