/**
 * @file src/components/goals-overview.tsx
 * @fileoverview This component displays a static overview of the user's financial goals.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import { Plus, Target } from 'lucide-react';

export default function GoalsOverview() {
    const goals = [
        { name: 'Family Vacation to Japan', current: 4500, target: 15000, description: 'Saving for a 2-week trip.' },
        { name: 'New Car Fund', current: 8000, target: 35000, description: 'Replacing the old sedan.' },
        { name: 'Home Down Payment', current: 50000, target: 150000, description: 'For our future home.' },
        { name: 'Emergency Fund', current: 18000, target: 20000, description: '6 months of living expenses.' },
    ];
    
    const currencyFormatter = new Intl.NumberFormat('en-IL', {
        style: 'currency',
        currency: 'ILS',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      });

    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle className="flex items-center gap-2">
                        <Target className="h-6 w-6" />
                        Financial Goals
                    </CardTitle>
                    <CardDescription>Your progress towards your financial targets.</CardDescription>
                </div>
                <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Goal
                </Button>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {goals.map((goal, index) => (
                    <Card key={index} className="p-4 flex flex-col justify-between">
                        <div>
                            <h3 className="font-bold text-lg">{goal.name}</h3>
                            <p className="text-sm text-muted-foreground mb-3">{goal.description}</p>
                            <Progress value={(goal.current / goal.target) * 100} className="h-3" />
                        </div>
                        <div className="mt-3 text-sm flex justify-between items-end">
                            <span className="font-semibold text-primary">
                                {currencyFormatter.format(goal.current)}
                            </span>
                            <span className="text-xs text-muted-foreground">
                                Target: {currencyFormatter.format(goal.target)}
                            </span>
                        </div>
                    </Card>
                ))}
            </CardContent>
        </Card>
    );
}
