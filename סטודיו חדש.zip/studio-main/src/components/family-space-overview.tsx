/**
 * @file src/components/family-space-overview.tsx
 * @fileoverview This component displays a static overview of the user's Family Financial Space.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Plus, Users, Target, PiggyBank, MoreVertical } from 'lucide-react';
import Image from 'next/image';
import { Progress } from './ui/progress';

export default function FamilySpaceOverview() {
    
    const familyMembers = [
        { name: 'John Doe', role: 'Admin' },
        { name: 'Jane Doe', role: 'Member' },
        { name: 'Junior Doe', role: 'View-only' },
    ];

    const sharedGoals = [
        { name: 'Summer Vacation', current: 7500, target: 10000 },
        { name: 'Kitchen Renovation', current: 2500, target: 20000 },
    ];

    const currencyFormatter = new Intl.NumberFormat('en-IL', {
        style: 'currency',
        currency: 'ILS',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      });

    return (
        <div className="space-y-8">
            <section>
                <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                        <div>
                            <CardTitle className="flex items-center gap-2">
                                <Users className="h-6 w-6" />
                                Family Members
                            </CardTitle>
                            <CardDescription>Manage members of your financial space.</CardDescription>
                        </div>
                        <Button size="sm">
                            <Plus className="mr-2 h-4 w-4" /> Invite Member
                        </Button>
                    </CardHeader>
                    <CardContent className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {familyMembers.map((member, index) => (
                            <Card key={index} className="p-4 flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <Image 
                                        src={`https://i.pravatar.cc/150?u=${member.name.replace(' ', '')}`}
                                        alt={member.name}
                                        width={40}
                                        height={40}
                                        className="rounded-full"
                                    />
                                    <div>
                                        <p className="font-bold">{member.name}</p>
                                        <p className="text-xs text-muted-foreground">{member.role}</p>
                                    </div>
                                </div>
                                <Button variant="ghost" size="icon" aria-label={`Actions for ${member.name}`}>
                                    <MoreVertical className="h-4 w-4" />
                                </Button>
                            </Card>
                        ))}
                    </CardContent>
                </Card>
            </section>
             <section>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <Target className="h-6 w-6" />
                            Shared Financial Goals
                        </CardTitle>
                        <CardDescription>Track progress on your collective goals.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        {sharedGoals.map((goal, index) => (
                            <div key={index}>
                                <div className="flex justify-between mb-1 text-sm">
                                    <span className="font-medium">{goal.name}</span>
                                    <span>{currencyFormatter.format(goal.current)} / {currencyFormatter.format(goal.target)}</span>
                                </div>
                                <Progress value={(goal.current / goal.target) * 100} />
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </section>
             <section>
                <Card>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <PiggyBank className="h-6 w-6" />
                            Shared Budgets
                        </CardTitle>
                        <CardDescription>Monitor collective spending categories.</CardDescription>
                    </CardHeader>
                    <CardContent>
                       <p className="text-center text-sm text-muted-foreground p-8">
                           Shared budgets feature coming soon.
                       </p>
                    </CardContent>
                </Card>
            </section>
        </div>
    );
}
