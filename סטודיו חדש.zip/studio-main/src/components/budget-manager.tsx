/**
 * @file src/components/budget-manager.tsx
 * @fileoverview This component allows users to create, view, edit, and delete their monthly budgets
 * for different expense categories. It uses a dialog for creating/editing and lists the current budgets.
 */
'use client';

import { useState, useMemo, FormEvent, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useFirebase } from '@/firebase';
import { collection, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Plus, Pencil, Trash2 } from 'lucide-react';
import { FirestorePermissionError } from '@/firebase/errors';
import { errorEmitter } from '@/firebase/error-emitter';
import { v4 as uuidv4 } from 'uuid';

/**
 * Defines the shape of a Budget object as stored in Firestore.
 */
export interface Budget {
  id: string;
  userId: string;
  category: string;
  amount: number;
  year: number;
  month: number;
}

interface BudgetManagerProps {
  budgets: Budget[] | null;
  isLoading: boolean;
}

/**
 * The main component for managing budgets.
 * It displays a list of current monthly budgets and provides functionality
 * to add, edit, or delete them through a dialog form.
 *
 * @param {BudgetManagerProps} props - Props containing budget data and loading state.
 * @returns {JSX.Element} The budget management component.
 */
export default function BudgetManager({ budgets, isLoading }: BudgetManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<Budget | null>(null);
  const [category, setCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const categoryInputRef = useRef<HTMLInputElement>(null);


  const { firestore, user } = useFirebase();
  const { toast } = useToast();

  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();
  
  /**
   * Memoized list of budgets for the current month.
   * This avoids re-filtering on every render.
   */
  const currentBudgets = useMemo(() => {
    return budgets?.filter(b => b.year === currentYear && b.month === currentMonth) || [];
  }, [budgets, currentYear, currentMonth]);

  useEffect(() => {
    if (isDialogOpen) {
      setTimeout(() => {
        categoryInputRef.current?.focus();
      }, 100);
    }
  }, [isDialogOpen]);

  /**
   * Opens the dialog to add a new budget, resetting the form fields.
   */
  const handleAddNew = () => {
    setEditingBudget(null);
    setCategory('');
    setAmount('');
    setIsDialogOpen(true);
  };

  /**
   * Opens the dialog to edit an existing budget, pre-filling the form fields.
   * @param {Budget} budget - The budget object to edit.
   */
  const handleEdit = (budget: Budget) => {
    setEditingBudget(budget);
    setCategory(budget.category);
    setAmount(String(budget.amount));
    setIsDialogOpen(true);
  };

  /**
   * Handles the deletion of a budget document from Firestore.
   * @param {string} budgetId - The ID of the budget to delete.
   */
  const handleDelete = async (budgetId: string) => {
    if (!firestore || !user) return;
    
    const docRef = doc(firestore, 'users', user.uid, 'budgets', budgetId);
    
    deleteDoc(docRef)
      .then(() => {
        toast({ title: 'Budget Deleted', description: 'The budget has been successfully removed.' });
      })
      .catch((err) => {
        const permissionError = new FirestorePermissionError({
          path: docRef.path,
          operation: 'delete',
        });
        errorEmitter.emit('permission-error', permissionError);
      });
  };

  /**
   * Handles the form submission for creating or updating a budget.
   * @param {FormEvent} e - The form event.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!firestore || !user || !category.trim() || !amount) {
      toast({ variant: 'destructive', title: 'Missing Fields', description: 'Please fill out all fields.' });
      return;
    }
    setIsSubmitting(true);

    const budgetData = {
      userId: user.uid,
      category: category.trim(),
      amount: parseFloat(amount),
      year: currentYear,
      month: currentMonth,
    };

    let docRef;
    let operation: 'create' | 'update' = 'create';
    let dataToSend: Budget;

    if (editingBudget) { // Update existing budget
      operation = 'update';
      docRef = doc(firestore, 'users', user.uid, 'budgets', editingBudget.id);
      dataToSend = { ...budgetData, id: editingBudget.id };
      
      setDoc(docRef, dataToSend, { merge: true })
        .then(() => {
          toast({ title: 'Budget Updated', description: 'Your budget has been successfully updated.' });
          setIsDialogOpen(false);
        })
        .catch((err) => {
          const permissionError = new FirestorePermissionError({
            path: docRef.path,
            operation: operation,
            requestResourceData: dataToSend,
          });
          errorEmitter.emit('permission-error', permissionError);
        })
        .finally(() => setIsSubmitting(false));

    } else { // Create new budget
      const newId = uuidv4();
      docRef = doc(firestore, 'users', user.uid, 'budgets', newId);
      dataToSend = { ...budgetData, id: newId };
      
      setDoc(docRef, dataToSend)
        .then(() => {
          toast({ title: 'Budget Created', description: 'Your new budget has been successfully set.' });
          setIsDialogOpen(false);
        })
        .catch((err) => {
           const permissionError = new FirestorePermissionError({
            path: docRef.path,
            operation: operation,
            requestResourceData: dataToSend,
          });
          errorEmitter.emit('permission-error', permissionError);
        })
        .finally(() => setIsSubmitting(false));
    }
  };


  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Monthly Budgets</CardTitle>
          <CardDescription>Manage your spending goals for this month.</CardDescription>
        </div>
        <Button size="sm" onClick={handleAddNew}>
          <Plus className="mr-2 h-4 w-4" /> Add Budget
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : currentBudgets.length > 0 ? (
          <ul className="space-y-3">
            {currentBudgets.map(budget => (
              <li key={budget.id} className="flex items-center justify-between rounded-md border p-3">
                <div>
                  <p className="font-medium">{budget.category}</p>
                  <p className="text-sm text-muted-foreground">₪{new Intl.NumberFormat('en-IL').format(budget.amount)}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" onClick={() => handleEdit(budget)} aria-label={`Edit ${budget.category} budget`}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(budget.id)} aria-label={`Delete ${budget.category} budget`}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-center text-sm text-muted-foreground p-4">No budgets set for this month.</p>
        )}
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingBudget ? 'Edit Budget' : 'Add New Budget'}</DialogTitle>
            <DialogDescription>
              Set a spending limit for an expense category for the current month.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="category" className="text-right">
                  Category
                </Label>
                <Input
                  id="category"
                  ref={categoryInputRef}
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="col-span-3"
                  placeholder="e.g., Groceries"
                  required
                  disabled={isSubmitting}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="amount" className="text-right">
                  Amount
                </Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="col-span-3"
                  placeholder="0.00"
                  required
                  disabled={isSubmitting}
                />
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button type="button" variant="secondary" disabled={isSubmitting}>
                  Cancel
                </Button>
              </DialogClose>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Save'}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
