'use server';

import { GoogleGenerativeAI } from '@google/generative-ai';

// Type definition for the structured output we expect from the AI model.
export interface QueryResult {
  response: string;
  imageUrl?: string;
  query: string;
}

// Type definition for image data passed from the client.
interface ImageInput {
  base64: string;
  mimeType: string;
}

// Ensure the API key is available.
if (!process.env.GEMINI_API_KEY) {
  throw new Error('GEMINI_API_KEY environment variable is not set.');
}

// Initialize the Google Generative AI client.
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

/**
 * The main server action that the client calls.
 * It takes a user query and optional image, processes them with the Gemini model,
 * and returns a structured result.
 * @param query The user's text query.
 * @param image Optional image data for vision-based queries.
 * @returns A promise that resolves to a QueryResult or an error object.
 */
export async function submitQuery(
  query: string,
  image?: ImageInput
): Promise<QueryResult | { error: string }> {
  try {
    // Select the model based on whether an image is provided.
    const modelName = image ? 'gemini-pro-vision' : 'gemini-pro';
    const model = genAI.getGenerativeModel({
      model: modelName,
      // Enforce JSON output for consistent, predictable responses.
      generationConfig: {
        responseMimeType: 'application/json',
      },
    });

    // Construct the prompt parts.
    const promptParts = [
      // System instruction defining the AI's persona and output format.
      `You are a helpful AI financial advisor for "Mishpucha Finance".
      Your response must be a valid JSON object with the following structure:
      {
        "response": "Your detailed and helpful textual answer to the user's query.",
        "imageUrl": "A placeholder image URL (e.g., from picsum.photos) ONLY if the query explicitly asks for an image or visualization. Otherwise, this should be omitted."
      }`,
      // User's query.
      `User query: ${query}`,
    ];

    let result;
    if (image) {
      // For vision queries, combine the prompt text with the image data.
      const imagePart = {
        inlineData: {
          data: image.base64,
          mimeType: image.mimeType,
        },
      };
      result = await model.generateContent([...promptParts, imagePart]);
    } else {
      // For text-only queries.
      result = await model.generateContent(promptParts);
    }
    
    const responseText = result.response.text();
    // The model is instructed to return JSON, so we parse it.
    const parsedResult = JSON.parse(responseText);

    return {
      response: parsedResult.response,
      imageUrl: parsedResult.imageUrl,
      query: query,
    };
  } catch (error: any) {
    console.error('Failed to execute AI query:', error);
    // Return a structured error to the client.
    return {
      error: error.message || 'An internal error occurred while processing the request.',
    };
  }
}
