/**
 * @file src/app/signup/page.tsx
 * @fileoverview This file contains the signup page component. It provides a form for new users
 * to create an account with their name, email, and password. It uses Firebase Authentication
 * to create the user and Firestore to store additional user profile information.
 */
'use client';

import { useState, FormEvent, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useFirebase, useUser } from '@/firebase';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Coins } from 'lucide-react';
import { useLanguage } from '@/contexts/language-context';

/**
 * Renders the signup page for the application.
 * @returns {JSX.Element} The signup page component.
 */
export default function SignupPage() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { auth, firestore } = useFirebase();
  const { toast } = useToast();
  const { user, isUserLoading } = useUser();
  const { t } = useLanguage();

  useEffect(() => {
    if (!isUserLoading && user) {
      router.replace('/dashboard');
    }
  }, [user, isUserLoading, router]);

  /**
   * Handles the form submission for user signup.
   * Creates a user in Firebase Auth, updates their profile with a display name,
   * and creates a corresponding user document in Firestore.
   * @param {FormEvent} e - The form event.
   */
  const handleSignup = async (e: FormEvent) => {
    e.preventDefault();
    if (!auth || !firestore) {
      toast({
        variant: 'destructive',
        title: t('errorTitle'),
        description: t('firebaseNotInitialized'),
      });
      return;
    }
    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const name = `${firstName} ${lastName}`.trim();
      
      // Update Firebase Auth profile
      await updateProfile(user, {
        displayName: name,
      });

      // Create user document in Firestore
      const userDocRef = doc(firestore, 'users', user.uid);
      await setDoc(userDocRef, {
        id: user.uid,
        email: user.email,
        name: name,
        createdAt: new Date().toISOString(),
      });

      router.push('/dashboard');

    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: t('signUpFailedTitle'),
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  if (isUserLoading || user) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full items-center justify-center bg-background">
      <Card className="mx-auto max-w-sm">
         <CardHeader>
           <div className="flex items-center justify-center mb-4">
              <Coins className="h-10 w-10 text-primary" />
            </div>
          <CardTitle className="text-2xl text-center">{t('signUpTitle')}</CardTitle>
          <CardDescription className="text-center">
            {t('signUpSubtitle')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSignup} className="grid gap-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="first-name">{t('firstNameLabel')}</Label>
                <Input 
                  id="first-name" 
                  placeholder={t('firstNamePlaceholder')} 
                  required 
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  disabled={loading}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="last-name">{t('lastNameLabel')}</Label>
                <Input 
                  id="last-name" 
                  placeholder={t('lastNamePlaceholder')}
                  required 
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  disabled={loading}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">{t('emailLabel')}</Label>
              <Input
                id="email"
                type="email"
                placeholder="m@example.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">{t('passwordLabel')}</Label>
              <Input 
                id="password" 
                type="password" 
                required 
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={loading}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
                {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : t('createAccountButton')}
            </Button>
          </form>
          <div className="mt-4 text-center text-sm">
            {t('alreadyHaveAccountPrompt')}{' '}
            <Link href="/login" className="underline">
              {t('loginLink')}
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
