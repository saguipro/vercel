/**
 * @file src/app/layout.tsx
 * @fileoverview This is the root layout for the entire application. It wraps all pages
 * with essential context providers for theming, Firebase services, and language management.
 * It also sets up global styles and metadata.
 */
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from '@/components/theme-provider';
import { FirebaseClientProvider } from '@/firebase';
import { LanguageProvider } from '@/contexts/language-context';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' });

export const metadata: Metadata = {
  title: 'Family Finance',
  description: 'A shared budget for you and your family',
};

/**
 * RootLayout component that structures the HTML for all pages.
 *
 * It establishes the core provider stack:
 * 1. ThemeProvider: For light/dark mode.
 * 2. FirebaseClientProvider: For initializing and providing Firebase services.
 * 3. LanguageProvider: For managing internationalization (i18n).
 *
 * @param {object} props - The component props.
 * @param {React.ReactNode} props.children - The child components to be rendered within the layout.
 * @returns {JSX.Element} The root layout element.
 */
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <FirebaseClientProvider>
            <LanguageProvider>
              {children}
              <Toaster />
            </LanguageProvider>
          </FirebaseClientProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
