/**
 * @file src/firebase/index.ts
 * @fileoverview This is the main "barrel" file for all Firebase-related functionality.
 * It initializes the Firebase app and exports all the necessary services, providers,
 * and hooks for easy and consistent use throughout the application.
 *
 * It exports:
 * - `initializeFirebase`: A function to initialize the Firebase app and get SDK instances.
 * - `FirebaseProvider`, `FirebaseClientProvider`: React context providers for Firebase services.
 * - `useFirebase`, `useAuth`, `useFirestore`, `useFirebaseApp`, `useUser`: Hooks to access Firebase services and user state.
 * - `useCollection`, `useDoc`: Hooks for real-time Firestore data.
 * - `useMemoFirebase`: A utility hook to memoize Firebase queries and references.
 * - Error handling utilities (`FirestorePermissionError`, `errorEmitter`).
 */
'use client';

import { firebaseConfig } from '@/firebase/config';
import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore } from 'firebase/firestore'
import { useMemo, DependencyList } from 'react';

/**
 * Initializes the Firebase application.
 * This function handles both server-side and client-side initialization,
 * ensuring that the app is initialized only once.
 *
 * @returns An object containing the initialized FirebaseApp, Auth, and Firestore instances.
 */
export function initializeFirebase() {
  const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
  return getSdks(app);
}

/**
 * A helper function to get the SDK instances from a FirebaseApp.
 * @param firebaseApp - The initialized FirebaseApp instance.
 * @returns An object containing the Auth and Firestore instances.
 */
export function getSdks(firebaseApp: FirebaseApp) {
  return {
    firebaseApp,
    auth: getAuth(firebaseApp),
    firestore: getFirestore(firebaseApp)
  };
}

// Re-export all providers, hooks, and utilities for easy access from a single entry point.
export * from './provider';
export * from './client-provider';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './auth/use-user';
export * from './errors';
export * from './error-emitter';

/**
 * A custom hook to memoize Firebase queries or document references.
 * This is CRITICAL to prevent infinite loops in `useCollection` and `useDoc` hooks,
 * which re-run their effects when their query/reference prop changes.
 *
 * @template T - The type of the value being memoized (e.g., Query, DocumentReference).
 * @param factory - A function that creates the Firebase query/reference.
 * @param deps - A dependency array, similar to `useMemo`.
 * @returns The memoized query/reference.
 */
type MemoFirebase <T> = T & {__memo?: boolean};
export function useMemoFirebase<T>(factory: () => T | null, deps: DependencyList): T | null {
  const memoized = useMemo(factory, deps);
  
  if(memoized && typeof memoized === 'object') {
    // This property is a trick to be able to verify that the memoization is happening
    (memoized as MemoFirebase<T>).__memo = true;
  }
  
  return memoized;
}
