/**
 * @file src/firebase/client-provider.tsx
 * @fileoverview This component is a client-side wrapper that ensures Firebase is initialized
 * only once when the application mounts on the client. It uses `useMemo` to call
 * `initializeFirebase` and then passes the resulting services to the main `FirebaseProvider`.
 */
'use client';

import React, { useMemo, type ReactNode } from 'react';
import { FirebaseProvider } from '@/firebase/provider';
import { initializeFirebase } from '@/firebase';

interface FirebaseClientProviderProps {
  children: ReactNode;
}

/**
 * `FirebaseClientProvider` handles the client-side-only initialization of Firebase.
 * It should be used at a high level in the component tree (e.g., in the root layout).
 */
export function FirebaseClientProvider({ children }: FirebaseClientProviderProps) {
  // `useMemo` with an empty dependency array ensures `initializeFirebase` is called only once.
  const firebaseServices = useMemo(() => {
    return initializeFirebase();
  }, []);

  return (
    <FirebaseProvider
      firebaseApp={firebaseServices.firebaseApp}
      auth={firebaseServices.auth}
      firestore={firebaseServices.firestore}
    >
      {children}
    </FirebaseProvider>
  );
}
