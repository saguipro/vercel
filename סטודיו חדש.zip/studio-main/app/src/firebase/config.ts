/**
 * @file src/firebase/config.ts
 * @fileoverview This file exports the Firebase configuration object.
 * This configuration is used to initialize the Firebase app.
 * IMPORTANT: This file is generated and should not be modified manually.
 */
export const firebaseConfig = {
  "projectId": "studio-9566208759-41b12",
  "appId": "1:659688362563:web:f7dbdfb875d120155f7af6",
  "apiKey": "AIzaSyCwYkpRPerhxq5hnIK7OGb8s5Srkxn3ub0",
  "authDomain": "studio-9566208759-41b12.firebaseapp.com",
  "measurementId": "G-Y35HGHEBMC",
  "storageBucket": "studio-9566208759-41b12.appspot.com",
  "messagingSenderId": "659688362563"
};
