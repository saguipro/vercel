/**
 * @file src/firebase/auth/use-user.tsx
 * @fileoverview This file defines the `useUser` hook, which provides a simple and direct
 * way to access the current user's authentication state from anywhere in the component tree.
 */
'use client';

import { useFirebase } from '@/firebase/provider';
import { User } from 'firebase/auth';

/** Defines the return type for the `useUser` hook. */
export interface UserHookResult {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

/**
 * A dedicated hook to access just the user's authentication state.
 * This is a lightweight convenience hook that extracts user-related state
 * from the main `useFirebase` hook.
 *
 * @returns {UserHookResult} An object containing the current user, loading state, and any authentication error.
 * @property {User | null} user - The current Firebase User object, or null if not authenticated.
 * @property {boolean} isUserLoading - True while the initial authentication state is being determined.
 * @property {Error | null} userError - Any error that occurred during the auth state observation.
 */
export const useUser = (): UserHookResult => {
  const { user, isUserLoading, userError } = useFirebase();
  return { user, isUserLoading, userError };
};
