/**
 * @file src/firebase/firestore/use-collection.tsx
 * @fileoverview This file defines the `useCollection` hook, a custom React hook for subscribing
 * to a Firestore collection or query in real-time. It handles loading states, errors, and
 * automatically unsubscribes on unmount. It also integrates with the global error emitter
 * to propagate permission errors for centralized handling.
 */
'use client';

import { useState, useEffect } from 'react';
import {
  Query,
  onSnapshot,
  DocumentData,
  FirestoreError,
  QuerySnapshot,
  CollectionReference,
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/** A utility type to ensure the document's `id` is included with its data. */
export type WithId<T> = T & { id: string };

/** Defines the shape of the object returned by the `useCollection` hook. */
export interface UseCollectionResult<T> {
  data: WithId<T>[] | null;
  isLoading: boolean;
  error: FirestoreError | Error | null;
}

/**
 * A private interface to access internal properties of a Firestore Query object
 * for robustly determining the collection path, even for complex queries. This is
 * necessary for creating detailed permission error messages.
 */
export interface InternalQuery extends Query<DocumentData> {
  _query: {
    path: {
      canonicalString(): string;
    }
  }
}

/**
 * A React hook to subscribe to a Firestore collection or query in real-time.
 *
 * CRITICAL: The `memoizedTargetRefOrQuery` parameter MUST be memoized using `useMemo` or
 * `useMemoFirebase` in the calling component. Failure to do so will result in a new
 * query object on every render, causing an infinite loop of subscriptions.
 *
 * @template T The expected type of the document data.
 * @param {CollectionReference | Query | null | undefined} memoizedTargetRefOrQuery The memoized Firestore query or collection reference.
 * @returns {UseCollectionResult<T>} An object containing the data, loading state, and error.
 */
export function useCollection<T = any>(
    memoizedTargetRefOrQuery: ((CollectionReference<DocumentData> | Query<DocumentData>) & {__memo?: boolean})  | null | undefined,
): UseCollectionResult<T> {
  type ResultItemType = WithId<T>;
  type StateDataType = ResultItemType[] | null;

  const [data, setData] = useState<StateDataType>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<FirestoreError | Error | null>(null);

  useEffect(() => {
    // If the query/ref is not ready, reset the state and do nothing.
    if (!memoizedTargetRefOrQuery) {
      setData(null);
      setIsLoading(true);
      setError(null);
      return;
    }

    setIsLoading(true);
    setError(null);

    const unsubscribe = onSnapshot(
      memoizedTargetRefOrQuery,
      (snapshot: QuerySnapshot<DocumentData>) => {
        // Map snapshot documents to data objects, including the ID.
        const results: ResultItemType[] = snapshot.docs.map(doc => ({ ...(doc.data() as T), id: doc.id }));
        setData(results);
        setError(null);
        setIsLoading(false);
      },
      (error: FirestoreError) => {
        // On permission error, determine the path and create a detailed, contextual error.
        const path: string =
          memoizedTargetRefOrQuery.type === 'collection'
            ? (memoizedTargetRefOrQuery as CollectionReference).path
            : (memoizedTargetRefOrQuery as unknown as InternalQuery)._query.path.canonicalString()

        const contextualError = new FirestorePermissionError({
          operation: 'list',
          path,
        });

        setError(contextualError);
        setData(null);
        setIsLoading(false);

        // Emit the error globally so it can be caught by the FirebaseErrorListener.
        errorEmitter.emit('permission-error', contextualError);
      }
    );

    // Cleanup function to unsubscribe from the listener on unmount.
    return () => unsubscribe();
  }, [memoizedTargetRefOrQuery]);

  // A runtime check to enforce memoization, throwing an error during development if forgotten.
  if(memoizedTargetRefOrQuery && !memoizedTargetRefOrQuery.__memo) {
    throw new Error('The query/reference passed to useCollection was not memoized with useMemoFirebase. This will cause infinite loops.');
  }

  return { data, isLoading, error };
}
