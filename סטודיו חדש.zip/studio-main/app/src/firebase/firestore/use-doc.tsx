/**
 * @file src/firebase/firestore/use-doc.tsx
 * @fileoverview This file defines the `useDoc` hook, a custom React hook for subscribing
 * to a single Firestore document in real-time. It manages loading states, errors, and
 * integrates with the global error emitter for centralized permission error handling.
 */
'use client';
    
import { useState, useEffect } from 'react';
import {
  DocumentReference,
  onSnapshot,
  DocumentData,
  FirestoreError,
  DocumentSnapshot,
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/** A utility type to ensure the document's `id` is included with its data. */
type WithId<T> = T & { id: string };

/** Defines the shape of the object returned by the `useDoc` hook. */
export interface UseDocResult<T> {
  data: WithId<T> | null;
  isLoading: boolean;
  error: FirestoreError | Error | null;
}

/**
 * A React hook to subscribe to a single Firestore document in real-time.
 *
 * CRITICAL: The `memoizedDocRef` parameter MUST be memoized using `useMemo` or `useMemoFirebase`
 * in the calling component. Failure to do so will cause an infinite loop of subscriptions.
 *
 * @template T The expected type of the document data.
 * @param {DocumentReference | null | undefined} memoizedDocRef The memoized Firestore document reference.
 * @returns {UseDocResult<T>} An object containing the data, loading state, and error.
 */
export function useDoc<T = any>(
  memoizedDocRef: (DocumentReference<DocumentData> & {__memo?: boolean})  | null | undefined,
): UseDocResult<T> {
  type StateDataType = WithId<T> | null;

  const [data, setData] = useState<StateDataType>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<FirestoreError | Error | null>(null);

  useEffect(() => {
    // If the reference is not ready, reset the state and do nothing.
    if (!memoizedDocRef) {
      setData(null);
      setIsLoading(true);
      setError(null);
      return;
    }

    setIsLoading(true);
    setError(null);

    const unsubscribe = onSnapshot(
      memoizedDocRef,
      (snapshot: DocumentSnapshot<DocumentData>) => {
        // If the document exists, set its data (including the ID).
        if (snapshot.exists()) {
          setData({ ...(snapshot.data() as T), id: snapshot.id });
        } else {
          // If the document does not exist, set data to null.
          setData(null);
        }
        setError(null);
        setIsLoading(false);
      },
      (error: FirestoreError) => {
        // On permission error, create a detailed, contextual error object.
        const contextualError = new FirestorePermissionError({
          operation: 'get',
          path: memoizedDocRef.path,
        });

        setError(contextualError);
        setData(null);
        setIsLoading(false);

        // Emit the error globally for centralized handling.
        errorEmitter.emit('permission-error', contextualError);
      }
    );

    // Cleanup function to unsubscribe on unmount.
    return () => unsubscribe();
  }, [memoizedDocRef]);

  // A runtime check to enforce memoization during development.
  if(memoizedDocRef && !memoizedDocRef.__memo) {
    throw new Error('The document reference passed to useDoc was not memoized with useMemoFirebase. This will cause infinite loops.');
  }

  return { data, isLoading, error };
}
