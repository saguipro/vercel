/**
 * @file src/firebase/errors.ts
 * @fileoverview This file defines a custom `FirestorePermissionError` class and related helpers.
 * This error is specifically designed to capture the context of a failed Firestore operation
 * in a format that mimics the `request` object available within Firestore Security Rules.
 * This provides extremely detailed, actionable error messages for debugging security rule denials.
 */
'use client';
import { getAuth, type User } from 'firebase/auth';

/** Defines the context of a Firestore operation, used to build the error. */
export type SecurityRuleContext = {
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete' | 'write';
  requestResourceData?: any; // The data being sent with a write operation
};

// Mirrors the structure of the `request.auth.token` object in security rules.
interface FirebaseAuthToken {
  name: string | null;
  picture: string | null;
  email: string | null;
  email_verified: boolean;
  phone_number: string | null;
  sub: string;
  firebase: {
    identities: Record<string, any>;
    sign_in_provider: string;
    tenant: string | null;
  };
}

// Mirrors the structure of the `request.auth` object in security rules.
interface FirebaseAuthObject {
  uid: string;
  token: FirebaseAuthToken;
}

// Mirrors the structure of the top-level `request` object in security rules.
interface SecurityRuleRequest {
  auth: FirebaseAuthObject | null;
  method: string;
  path: string;
  resource?: {
    data: any;
  };
}

/**
 * Builds a `request.auth`-like object from a client-side Firebase User object.
 * @param currentUser The currently authenticated Firebase user.
 * @returns An object mirroring `request.auth` in security rules, or null if unauthenticated.
 */
function buildAuthObject(currentUser: User | null): FirebaseAuthObject | null {
  if (!currentUser) {
    return null;
  }

  // Aggregate provider data into the `identities` object.
  const identities = currentUser.providerData.reduce((acc, p) => {
    if (p.providerId) {
      // Create a nested object for each provider
      acc[p.providerId] = {
        "uid": p.uid,
        "email": p.email
      };
    }
    return acc;
  }, {} as Record<string, any>);


  const token: FirebaseAuthToken = {
    name: currentUser.displayName,
    picture: currentUser.photoURL,
    email: currentUser.email,
    email_verified: currentUser.emailVerified,
    phone_number: currentUser.phoneNumber,
    sub: currentUser.uid, // 'sub' is the standard JWT claim for subject (user ID)
    firebase: {
      identities,
      sign_in_provider: currentUser.providerData?.[0]?.providerId ?? 'custom',
      tenant: currentUser.tenantId,
    },
  };

  return {
    uid: currentUser.uid,
    token: token,
  };
}

/**
 * Builds the complete, simulated `request` object for the error message.
 * @param context The context of the failed Firestore operation.
 * @returns A structured request object for debugging.
 */
function buildRequestObject(context: SecurityRuleContext): SecurityRuleRequest {
  let authObject: FirebaseAuthObject | null = null;
  try {
    // This might fail if Firebase isn't initialized yet, so we wrap it.
    const currentUser = getAuth().currentUser;
    authObject = buildAuthObject(currentUser);
  } catch (e) {
    // It's okay if this fails; we'll just show an unauthenticated request.
  }

  return {
    auth: authObject,
    method: context.operation,
    path: `/databases/(default)/documents/${context.path}`,
    ...(context.requestResourceData && { resource: { data: context.requestResourceData } }),
  };
}

/**
 * Formats the final, detailed error message string.
 * @param requestObject The simulated request object.
 * @returns A string containing the error title and the pretty-printed JSON payload.
 */
function buildErrorMessage(requestObject: SecurityRuleRequest): string {
  return `FirestoreError: Missing or insufficient permissions: The following request was denied by Firestore Security Rules:\n${JSON.stringify(requestObject, null, 2)}`;
}

/**
 * A custom error class that provides rich, contextual information about a
 * Firestore permission error. It is designed to be thrown and caught by
 * a global error handler (like Next.js's error overlay) to display
 * highly detailed debugging information.
 */
export class FirestorePermissionError extends Error {
  public readonly request: SecurityRuleRequest;

  constructor(context: SecurityRuleContext) {
    const requestObject = buildRequestObject(context);
    super(buildErrorMessage(requestObject));
    this.name = 'FirestorePermissionError';
    this.request = requestObject;

    // This is for V8's stack trace API
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, FirestorePermissionError);
    }
  }
}
