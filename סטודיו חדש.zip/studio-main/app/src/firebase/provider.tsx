/**
 * @file src/firebase/provider.tsx
 * @fileoverview This file defines the core `FirebaseProvider` and the hooks used to access
 * Firebase services (`useFirebase`, `useAuth`, `useFirestore`, etc.). The provider is
 * responsible for managing and providing the Firebase app, auth, and firestore instances,
 * as well as tracking the current user's authentication state.
 */
'use client';

import React, { createContext, useContext, ReactNode, useMemo, useState, useEffect } from 'react';
import { FirebaseApp } from 'firebase/app';
import { Firestore } from 'firebase/firestore';
import { Auth, User, onAuthStateChanged } from 'firebase/auth';
import { FirebaseErrorListener } from '@/components/FirebaseErrorListener';

interface FirebaseProviderProps {
  children: ReactNode;
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
}

// Defines the shape of the user authentication state.
interface UserAuthState {
  user: User | null;
  isUserLoading: boolean;
  userError: Error | null;
}

// Defines the complete state managed by the Firebase context.
export interface FirebaseContextState extends UserAuthState {
  areServicesAvailable: boolean;
  firebaseApp: FirebaseApp | null;
  firestore: Firestore | null;
  auth: Auth | null;
}

// Defines the return type for the main `useFirebase` hook.
export interface FirebaseServicesAndUser extends UserAuthState {
  firebaseApp: FirebaseApp;
  firestore: Firestore;
  auth: Auth;
}

// Create the React Context for Firebase services.
export const FirebaseContext = createContext<FirebaseContextState | undefined>(undefined);

/**
 * The `FirebaseProvider` component. It manages Firebase service instances and user
 * authentication state, making them available to all child components.
 */
export const FirebaseProvider: React.FC<FirebaseProviderProps> = ({
  children,
  firebaseApp,
  firestore,
  auth,
}) => {
  const [userAuthState, setUserAuthState] = useState<UserAuthState>({
    user: auth.currentUser, // Initialize with the current user if available
    isUserLoading: true,    // Start in loading state
    userError: null,
  });

  // Effect to subscribe to authentication state changes.
  useEffect(() => {
    setUserAuthState({ user: auth.currentUser, isUserLoading: true, userError: null });

    const unsubscribe = onAuthStateChanged(
      auth,
      (firebaseUser) => {
        setUserAuthState({ user: firebaseUser, isUserLoading: false, userError: null });
      },
      (error) => {
        console.error("FirebaseProvider: onAuthStateChanged error:", error);
        setUserAuthState({ user: null, isUserLoading: false, userError: error });
      }
    );
    return () => unsubscribe(); // Cleanup subscription on unmount
  }, [auth]);

  // Memoize the context value to prevent unnecessary re-renders of consumers.
  const contextValue = useMemo((): FirebaseContextState => {
    const servicesAvailable = !!(firebaseApp && firestore && auth);
    return {
      areServicesAvailable: servicesAvailable,
      firebaseApp: servicesAvailable ? firebaseApp : null,
      firestore: servicesAvailable ? firestore : null,
      auth: servicesAvailable ? auth : null,
      ...userAuthState,
    };
  }, [firebaseApp, firestore, auth, userAuthState]);

  return (
    <FirebaseContext.Provider value={contextValue}>
      <FirebaseErrorListener />
      {children}
    </FirebaseContext.Provider>
  );
};

/**
 * The main hook to access all core Firebase services and the user's auth state.
 * Throws an error if used outside a FirebaseProvider or if services are unavailable.
 */
export const useFirebase = (): FirebaseServicesAndUser => {
  const context = useContext(FirebaseContext);

  if (context === undefined) {
    throw new Error('useFirebase must be used within a FirebaseProvider.');
  }

  if (!context.areServicesAvailable || !context.firebaseApp || !context.firestore || !context.auth) {
    throw new Error('Firebase core services not available. Check FirebaseProvider setup.');
  }

  return {
    firebaseApp: context.firebaseApp,
    firestore: context.firestore,
    auth: context.auth,
    user: context.user,
    isUserLoading: context.isUserLoading,
    userError: context.userError,
  };
};

/** Hook to access just the Firebase Auth instance. */
export const useAuth = (): Auth => useFirebase().auth;

/** Hook to access just the Firestore instance. */
export const useFirestore = (): Firestore => useFirebase().firestore;

/** Hook to access just the Firebase App instance. */
export const useFirebaseApp = (): FirebaseApp => useFirebase().firebaseApp;
