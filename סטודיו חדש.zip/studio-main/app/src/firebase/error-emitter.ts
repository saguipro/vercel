/**
 * @file src/firebase/error-emitter.ts
 * @fileoverview This file defines a strongly-typed, global event emitter (pub/sub) system.
 * It is primarily used to propagate `FirestorePermissionError` instances from deep within
 * data hooks or functions up to a top-level listener component (`FirebaseErrorListener`)
 * without relying on React's standard error boundaries, which don't catch async errors well.
 */
'use client';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * Defines all possible events and their corresponding payload types.
 * This ensures type safety when emitting and listening to events.
 */
export interface AppEvents {
  'permission-error': FirestorePermissionError;
}

// A generic type for a listener/callback function.
type Callback<T> = (data: T) => void;

/**
 * Creates a strongly-typed event emitter.
 * @template T A record mapping event names to their payload types.
 */
function createEventEmitter<T extends Record<string, any>>() {
  const events: { [K in keyof T]?: Array<Callback<T[K]>> } = {};

  return {
    /**
     * Subscribes a listener to an event.
     * @param eventName The name of the event.
     * @param callback The function to execute when the event is emitted.
     */
    on<K extends keyof T>(eventName: K, callback: Callback<T[K]>) {
      if (!events[eventName]) {
        events[eventName] = [];
      }
      events[eventName]?.push(callback);
    },

    /**
     * Unsubscribes a listener from an event.
     * @param eventName The name of the event.
     * @param callback The specific callback function to remove.
     */
    off<K extends keyof T>(eventName: K, callback: Callback<T[K]>) {
      events[eventName] = events[eventName]?.filter(cb => cb !== callback);
    },

    /**
     * Publishes an event to all its subscribers.
     * @param eventName The name of the event to emit.
     * @param data The payload to send to the listeners.
     */
    emit<K extends keyof T>(eventName: K, data: T[K]) {
      events[eventName]?.forEach(callback => callback(data));
    },
  };
}

// Create and export a singleton instance of the emitter for the application.
export const errorEmitter = createEventEmitter<AppEvents>();
