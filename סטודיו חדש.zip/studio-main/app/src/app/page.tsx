/**
 * @file src/app/page.tsx
 * @fileoverview This is the root page of the application. It automatically redirects
 * authenticated users to their main dashboard.
 */
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/firebase';
import { Loader2 } from 'lucide-react';

/**
 * The main component for the application's root page.
 * It shows a loader while checking auth state and then redirects to the appropriate page.
 */
export default function Home() {
  const { user, isUserLoading } = useUser();
  const router = useRouter();

  useEffect(() => {
    if (!isUserLoading) {
      if (user) {
        router.replace('/dashboard');
      } else {
        router.replace('/login');
      }
    }
  }, [user, isUserLoading, router]);

  // Display a loading spinner while checking authentication state.
  return (
    <div className="flex h-screen items-center justify-center bg-background">
      <Loader2 className="h-16 w-16 animate-spin text-primary" />
    </div>
  );
}
