/**
 * @file src/app/dashboard/page.tsx
 * @fileoverview The main dashboard page for authenticated users.
 * It protects the route and displays the user's financial overview and
 * the main application content.
 */
'use client';

import { useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUser, useFirebase, useCollection, useMemoFirebase } from '@/firebase';
import { signOut } from 'firebase/auth';
import { Button } from '@/components/ui/button';
import { Loader2, Coins, LogOut } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { useLanguage } from '@/contexts/language-context';
import LanguageSwitcher from '@/components/language-switcher';
import { collection, query, where, orderBy } from 'firebase/firestore';

interface Transaction {
    id: string;
    amount: number;
    date: string;
}

function MetricCard({ title, value, currency, isLoading }: { title: string; value: number; currency: string; isLoading: boolean; }) {
    return (
        <Card className="text-center p-4">
            <h3 className="text-sm text-muted-foreground mb-2">{title}</h3>
            {isLoading ? (
                <div className="flex justify-center items-center h-9">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
            ) : (
                <p className="text-3xl font-bold text-foreground">
                    {currency}{value.toLocaleString()}
                </p>
            )}
        </Card>
    );
}

function CashFlowChart({ data, title, isLoading }: { data: { month: string; income: number; expenses: number; }[], title: string, isLoading: boolean }) {
    const maxValue = Math.max(...data.map(d => Math.max(d.income, d.expenses)), 1);
    const { t } = useLanguage();

    return (
        <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">{title}</h3>
             {isLoading ? (
                <div className="flex justify-center items-center h-48">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
             ) : (
                <div className="space-y-4">
                    {data.map((item, index) => (
                        <div key={index} className="space-y-1">
                            <div className="text-xs text-muted-foreground">{item.month}</div>
                            <div className="flex gap-2">
                                <div className="flex-1 space-y-1">
                                    <div className="text-xs text-green-600">{t('incomeLabel')}</div>
                                    <div className="bg-gray-100 h-6 rounded overflow-hidden">
                                        <div 
                                            className="bg-green-500 h-full"
                                            style={{ width: `${(item.income / maxValue) * 100}%` }}
                                        />
                                    </div>
                                </div>
                                <div className="flex-1 space-y-1">
                                    <div className="text-xs text-red-600">{t('expensesLabel')}</div>
                                    <div className="bg-gray-100 h-6 rounded overflow-hidden">
                                        <div 
                                            className="bg-red-500 h-full"
                                            style={{ width: `${(item.expenses / maxValue) * 100}%` }}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </Card>
    );
}

function AssetDistributionChart({ title, totalLabel }: { title: string, totalLabel: string }) {
    const assets = [
        { name: 'Cash', value: 0, color: 'bg-blue-500' },
        { name: 'Investments', value: 0, color: 'bg-purple-500' },
        { name: 'Real Estate', value: 0, color: 'bg-green-500' },
        { name: 'Crypto', value: 0, color: 'bg-orange-500' }
    ];

    const total = assets.reduce((sum, asset) => sum + asset.value, 0);
    const { t } = useLanguage();

    return (
        <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">{title}</h3>
            <div className="space-y-3">
                {assets.map((asset, index) => (
                    <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <div className={`w-4 h-4 rounded ${asset.color}`} />
                            <span className="text-sm">{t(asset.name.toLowerCase() as any)}</span>
                        </div>
                        <div className="text-sm font-semibold">
                            ₪{asset.value.toLocaleString()} ({total > 0 ? ((asset.value / total) * 100).toFixed(0) : 0}%)
                        </div>
                    </div>
                ))}
                <div className="pt-3 border-t border-gray-200">
                    <div className="flex justify-between font-bold">
                        <span>{totalLabel}</span>
                        <span>₪{total.toLocaleString()}</span>
                    </div>
                </div>
            </div>
        </Card>
    );
}

function NavigationMenu() {
    const { t } = useLanguage();
    const menuItems = [
        { titleKey: 'incomeGrowthTitle', descriptionKey: 'incomeGrowthDesc', href: '/income' },
        { titleKey: 'expensesBudgetsTitle', descriptionKey: 'expensesBudgetsDesc', href: '/expenses' },
        { titleKey: 'savingsAssetsTitle', descriptionKey: 'savingsAssetsDesc', href: '/savings' },
        { titleKey: 'investmentsTitle', descriptionKey: 'investmentsDesc', href: '/investments' },
        { titleKey: 'cryptoTrackingTitle', descriptionKey: 'cryptoTrackingDesc', href: '/crypto' },
        { titleKey: 'goalTrackingTitle', descriptionKey: 'goalTrackingDesc', href: '/goals' },
        { titleKey: 'familySpaceTitle', descriptionKey: 'familySpaceDesc', href: '/family' },
        { titleKey: 'aiAdvisorTitle', descriptionKey: 'aiAdvisorDesc', href: '/advisor' },
        { titleKey: 'scenarioAnalysisTitle', descriptionKey: 'scenarioAnalysisDesc', href: '/scenario-analysis' },
        { titleKey: 'financialEducationTitle', descriptionKey: 'financialEducationDesc', href: '/education' }
    ];

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {menuItems.map((item, index) => (
                <Link href={item.href} key={index} legacyBehavior>
                    <a className="block">
                        <Card className="p-4 hover:shadow-lg transition-shadow cursor-pointer h-full">
                            <h4 className="text-foreground font-semibold mb-1">{t(item.titleKey as any)}</h4>
                            <p className="text-sm text-muted-foreground">{t(item.descriptionKey as any)}</p>
                        </Card>
                    </a>
                </Link>
            ))}
        </div>
    );
}


/**
 * Renders the user's main dashboard.
 * - Redirects unauthenticated users to the login page.
 * - Displays a header with the user's email and a sign-out button.
 * - Shows the financial overview component with real data.
 * @returns {JSX.Element} The dashboard page component.
 */
export default function DashboardPage() {
  const { user, isUserLoading } = useUser();
  const { auth, firestore } = useFirebase();
  const router = useRouter();
  const { t, language } = useLanguage();

  const now = new Date();
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
  const firstDayOfSixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1).toISOString().split('T')[0];

  const incomesQuery = useMemoFirebase(() => 
    user ? query(collection(firestore, 'users', user.uid, 'incomes'), where('date', '>=', firstDayOfMonth)) : null,
  [user, firestore, firstDayOfMonth]);
  
  const expensesQuery = useMemoFirebase(() => 
    user ? query(collection(firestore, 'users', user.uid, 'expenses'), where('date', '>=', firstDayOfMonth)) : null,
  [user, firestore, firstDayOfMonth]);

  const recentIncomesQuery = useMemoFirebase(() => 
    user ? query(collection(firestore, 'users', user.uid, 'incomes'), where('date', '>=', firstDayOfSixMonthsAgo), orderBy('date', 'desc')) : null,
  [user, firestore, firstDayOfSixMonthsAgo]);
  
  const recentExpensesQuery = useMemoFirebase(() => 
    user ? query(collection(firestore, 'users', user.uid, 'expenses'), where('date', '>=', firstDayOfSixMonthsAgo), orderBy('date', 'desc')) : null,
  [user, firestore, firstDayOfSixMonthsAgo]);

  const { data: monthlyIncomes, isLoading: incomesLoading } = useCollection<Transaction>(incomesQuery);
  const { data: monthlyExpenses, isLoading: expensesLoading } = useCollection<Transaction>(expensesQuery);
  const { data: recentIncomes, isLoading: recentIncomesLoading } = useCollection<Transaction>(recentIncomesQuery);
  const { data: recentExpenses, isLoading: recentExpensesLoading } = useCollection<Transaction>(recentExpensesQuery);


  useEffect(() => {
    document.documentElement.dir = language === 'he' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.replace('/login');
    }
  }, [user, isUserLoading, router]);

  const handleSignOut = async () => {
    if (auth) {
      await signOut(auth);
      router.push('/login');
    }
  };

  const financialMetrics = useMemo(() => {
    const income = monthlyIncomes?.reduce((sum, item) => sum + item.amount, 0) || 0;
    const expenses = monthlyExpenses?.reduce((sum, item) => sum + item.amount, 0) || 0;
    return {
      monthlyIncome: income,
      monthlyExpenses: expenses,
      savings: income - expenses,
      totalAssets: 0 // Placeholder
    };
  }, [monthlyIncomes, monthlyExpenses]);
  
  const cashFlowData = useMemo(() => {
    const monthNames = [t('jan'), t('feb'), t('mar'), t('apr'), t('may'), t('jun'), t('jul'), t('aug'), t('sep'), t('oct'), t('nov'), t('dec')];
    const months = Array.from({ length: 6 }, (_, i) => {
        const d = new Date();
        d.setMonth(now.getMonth() - i);
        return { month: monthNames[d.getMonth()], year: d.getFullYear(), income: 0, expenses: 0 };
    }).reverse();

    recentIncomes?.forEach(inc => {
        const d = new Date(inc.date + 'T00:00:00');
        const monthIndex = d.getMonth();
        const year = d.getFullYear();
        const target = months.find(m => m.month === monthNames[monthIndex] && m.year === year);
        if(target) target.income += inc.amount;
    });
    recentExpenses?.forEach(exp => {
        const d = new Date(exp.date + 'T00:00:00');
        const monthIndex = d.getMonth();
        const year = d.getFullYear();
        const target = months.find(m => m.month === monthNames[monthIndex] && m.year === year);
        if(target) target.expenses += exp.amount;
    });

    return months.map(({ month, income, expenses }) => ({ month, income, expenses }));

  }, [recentIncomes, recentExpenses, t, now.getMonth()]);

  if (isUserLoading || !user) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }
  
  const isLoading = incomesLoading || expensesLoading || recentIncomesLoading || recentExpensesLoading;

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="border-b p-4 shadow-sm bg-card sticky top-0 z-10">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center space-x-3">
            <Coins className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-semibold">{t('appTitle')}</h1>
          </div>
          <div className="flex items-center gap-4">
             <LanguageSwitcher />
             <span className="text-sm text-muted-foreground hidden sm:inline">{user.email}</span>
             <Button variant="outline" size="icon" onClick={handleSignOut} title={t('signOutTooltip')}>
                <LogOut className="h-5 w-5" />
             </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-7xl flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <div className="flex flex-col gap-8 sm:gap-12">
            <section>
                <h1 className="text-3xl font-bold tracking-tight mb-2">{t('dashboardTitle')}</h1>
                <p className="text-lg text-muted-foreground">
                    {t('dashboardSubtitle')}
                </p>
            </section>

            <section>
                <h2 className="text-2xl font-semibold mb-4">{t('financialOverviewTitle')}</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <MetricCard 
                        title={t('monthlyIncome')} 
                        value={financialMetrics.monthlyIncome}
                        currency="₪"
                        isLoading={isLoading}
                    />
                    <MetricCard 
                        title={t('monthlyExpenses')} 
                        value={financialMetrics.monthlyExpenses}
                        currency="₪"
                        isLoading={isLoading}
                    />
                    <MetricCard 
                        title={t('savings')} 
                        value={financialMetrics.savings}
                        currency="₪"
                        isLoading={isLoading}
                    />
                    <MetricCard 
                        title={t('totalAssets')} 
                        value={financialMetrics.totalAssets}
                        currency="₪"
                        isLoading={isLoading}
                    />
                </div>
            </section>

            <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <CashFlowChart data={cashFlowData} title={t('cashFlowTitle')} isLoading={isLoading} />
                <AssetDistributionChart title={t('assetDistributionTitle')} totalLabel={t('totalLabel')} />
            </section>

            <section>
                <h2 className="text-2xl font-semibold mb-4">{t('quickActionsTitle')}</h2>
                <NavigationMenu />
            </section>
        </div>
      </main>
    </div>
  );
}
