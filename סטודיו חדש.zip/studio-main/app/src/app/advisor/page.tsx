/**
 * @file src/app/advisor/page.tsx
 * @fileoverview This page is dedicated to the AI Financial Advisor.
 * It provides a protected route that displays the chat interface.
 */
'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useUser, useFirebase } from '@/firebase';
import { signOut } from 'firebase/auth';
import { Button } from '@/components/ui/button';
import { Loader2, Coins, LogOut, ChevronLeft } from 'lucide-react';
import AdvisorChat from '@/components/advisor-chat';
import LanguageSwitcher from '@/components/language-switcher';
import { useLanguage } from '@/contexts/language-context';

/**
 * The main page component for the AI Financial Advisor.
 * - Protects the route, redirecting to login if the user is not authenticated.
 * - Displays a header with navigation and user controls.
 * - Renders the `AdvisorChat` component.
 * @returns {JSX.Element} The advisor page component.
 */
export default function AdvisorPage() {
  const { user, isUserLoading } = useUser();
  const { auth } = useFirebase();
  const router = useRouter();
  const { t, language } = useLanguage();

   // Effect to set the document direction based on the current language.
  useEffect(() => {
    document.documentElement.dir = language === 'he' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    if (!isUserLoading && !user) {
      router.replace('/login');
    }
  }, [user, isUserLoading, router]);

  const handleSignOut = async () => {
    if (auth) {
      await signOut(auth);
      router.push('/login');
    }
  };

  if (isUserLoading || !user) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <Loader2 className="h-16 w-16 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-background">
      <header className="border-b p-4 shadow-sm bg-card sticky top-0 z-10">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center space-x-3">
            <Link href="/dashboard" passHref>
               <Button variant="outline" size="icon">
                 <ChevronLeft className="h-5 w-5" />
               </Button>
            </Link>
            <Coins className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-semibold">{t('aiAdvisorTitle')}</h1>
          </div>
          <div className="flex items-center gap-4">
             <LanguageSwitcher />
             <span className="text-sm text-muted-foreground hidden sm:inline">{user.email}</span>
             <Button variant="outline" size="icon" onClick={handleSignOut} title={t('signOutTooltip')}>
                <LogOut className="h-5 w-5" />
             </Button>
          </div>
        </div>
      </header>
      <main className="mx-auto w-full max-w-4xl flex-1 overflow-y-auto p-4 md:p-6 lg:p-8">
        <AdvisorChat />
      </main>
    </div>
  );
}