/**
 * @file src/contexts/language-context.tsx
 * @fileoverview This file establishes a React Context for managing internationalization (i18n).
 * It provides a `LanguageProvider` to wrap the application and a `useLanguage` hook
 * to access the current language's translations and change the language.
 */
'use client';

import React, { createContext, useState, useContext, ReactNode, useMemo, useCallback } from 'react';

// Import translation files
import en from '@/lib/locales/en.json';
import es from '@/lib/locales/es.json';
import he from '@/lib/locales/he.json';
import hi from '@/lib/locales/hi.json';

// Define available languages and the shape of translation files
type Language = 'en' | 'es' | 'he' | 'hi';
type Translations = typeof en;

// Store all translations in a single object
const translations: Record<Language, Translations> = { en, es, he, hi };

// Define the shape of the context state
interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: keyof Translations) => string;
}

// Create the React Context with a default undefined value
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

/**
 * Provides the language context to its children.
 * Manages the current language state and provides a function to translate keys.
 * @param {LanguageProviderProps} props - The component props.
 * @returns {JSX.Element} The provider component.
 */
export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  const [language, setLanguage] = useState<Language>('en'); // Default language is English

  /**
   * Translation function.
   * Takes a key from the translation file and returns the corresponding string
   * for the currently selected language.
   * Falls back to English if a key is not found in the current language.
   *
   * useCallback is used to memoize the function, preventing unnecessary re-renders
   * in child components that use it.
   */
  const t = useCallback((key: keyof Translations): string => {
    return translations[language]?.[key] || translations.en[key];
  }, [language]);

  // Memoize the context value to prevent re-renders of consumers
  // when the provider itself re-renders but the context value hasn't changed.
  const value = useMemo(() => ({
    language,
    setLanguage,
    t,
  }), [language, t]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

/**
 * Custom hook to access the language context.
 * Provides an easy way for components to get the current language,
 * change the language, and access the translation function `t`.
 * @returns {LanguageContextType} The language context value.
 * @throws {Error} If used outside of a `LanguageProvider`.
 */
export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
