/**
 * @fileoverview Defines the core AI advisor flow for the Family Finance app.
 * This file uses Genkit to create a structured, typed, and robust interaction
 * with the Gemini large language model. It includes a tool that allows the AI
 * to fetch and analyze the user's financial data from Firestore.
 *
 * It exports:
 * - `askAdvisor`: The main function to call the AI flow.
 * - `AdvisorInput`: The Zod schema for the flow's input.
 * - `AdvisorOutput`: The Zod schema for the flow's output.
 */
'use server';

import { ai } from '@/ai/genkit';
import { z } from 'zod';
import { initializeFirebase } from '@/firebase';
import { collection, getDocs, query, orderBy, limit } from 'firebase/firestore';

/**
 * Defines the schema for the data provided TO the advisor flow.
 * This ensures that any call to the flow provides data in the correct shape.
 *
 * @property {string} userId - The Firebase Auth UID of the user asking the question.
 * @property {string} question - The user's primary text query.
 * @property {string} [image] - An optional image for multimodal queries, provided as a data URI.
 */
export const AdvisorInputSchema = z.object({
  userId: z.string().describe("The user's Firebase Auth UID."),
  question: z.string().describe('The question the user is asking the financial advisor.'),
  image: z
    .string()
    .optional()
    .describe(
      "An optional image (e.g., of a receipt) to provide context for the question. Must be a data URI: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type AdvisorInput = z.infer<typeof AdvisorInputSchema>;

/**
 * Defines the schema for the data returned FROM the advisor flow.
 * This ensures the AI's response is always in a predictable JSON structure,
 * preventing errors from unexpected response formats.
 *
 * @property {string} response - The detailed, helpful textual answer to the user's query.
 * @property {string} [imageUrl] - A placeholder image URL, only included if the query explicitly asks for a visualization.
 */
export const AdvisorOutputSchema = z.object({
  response: z.string().describe("The AI's detailed and helpful textual answer to the user's query."),
  imageUrl: z
    .string()
    .optional()
    .describe(
      'A placeholder image URL (e.g., from picsum.photos) ONLY if the query explicitly asks for an image or visualization. Otherwise, this should be omitted.'
    ),
});
export type AdvisorOutput = z.infer<typeof AdvisorOutputSchema>;


/**
 * Defines a Genkit Tool that the AI can use to fetch a user's financial summary.
 * This tool securely connects to Firestore and aggregates income and expense data
 * for the specified user, providing a summary back to the AI model.
 */
const getFinancialSummary = ai.defineTool(
  {
    name: 'getFinancialSummary',
    description: "Fetches the user's financial summary, including total income, total expenses, recent transactions, and a breakdown of expenses by category. Use this tool when the user asks for analysis of their spending, financial status, or how they can save money.",
    input: z.object({ userId: z.string() }),
    output: z.object({
      totalIncome: z.number(),
      totalExpenses: z.number(),
      expenseBreakdown: z.record(z.number()),
      recentTransactions: z.array(z.object({
        type: z.string(),
        category: z.string(),
        amount: z.number(),
        date: z.string(),
      })),
      hasData: z.boolean(),
    }),
  },
  async ({ userId }) => {
    // Initialize a server-side Firebase instance to fetch data.
    const { firestore } = initializeFirebase();
    if (!firestore) {
      throw new Error('Firestore is not initialized.');
    }

    try {
      const incomesRef = collection(firestore, 'users', userId, 'incomes');
      const expensesRef = collection(firestore, 'users', userId, 'expenses');
      
      const [incomesSnapshot, expensesSnapshot] = await Promise.all([
        getDocs(query(incomesRef, orderBy('date', 'desc'), limit(100))),
        getDocs(query(expensesRef, orderBy('date', 'desc'), limit(100))),
      ]);

      const allTransactions: any[] = [];

      const totalIncome = incomesSnapshot.docs.reduce((sum, doc) => {
        const data = doc.data();
        allTransactions.push({ type: 'income', ...data });
        return sum + data.amount;
      }, 0);
      
      const totalExpenses = expensesSnapshot.docs.reduce((sum, doc) => {
         const data = doc.data();
        allTransactions.push({ type: 'expense', ...data });
        return sum + data.amount;
      }, 0);

      const expenseBreakdown = expensesSnapshot.docs.reduce((acc, doc) => {
        const { category, amount } = doc.data();
        if (!acc[category]) {
          acc[category] = 0;
        }
        acc[category] += amount;
        return acc;
      }, {} as Record<string, number>);

      // Sort all transactions by date and take the last 5
      allTransactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      const recentTransactions = allTransactions.slice(0, 5).map(t => ({
        type: t.type,
        category: t.category,
        amount: t.amount,
        date: t.date,
      }));


      const hasData = !incomesSnapshot.empty || !expensesSnapshot.empty;

      return { totalIncome, totalExpenses, expenseBreakdown, recentTransactions, hasData };
    } catch (error) {
      console.error('Error fetching financial summary:', error);
      // It's crucial to return a structured response even on error
      // so the AI knows the tool failed.
      return { totalIncome: 0, totalExpenses: 0, expenseBreakdown: {}, recentTransactions: [], hasData: false };
    }
  }
);


/**
 * Defines the Genkit prompt that instructs the AI model.
 * It specifies the AI's persona, the available tools, the expected input schema,
 * the mandatory output schema, and the prompt template itself using Handlebars syntax.
 */
const advisorPrompt = ai.definePrompt(
  {
    name: 'advisorPrompt',
    input: { schema: z.any() }, // Input is now flexible, handled by the flow
    output: { schema: AdvisorOutputSchema },
    tools: [getFinancialSummary], // Make the tool available to the AI
    prompt: `You are a helpful and insightful AI financial advisor for "Family Finance".
      
      Your response must be a valid JSON object that conforms to the specified output schema.
      
      Analyze the user's query and any provided financial data to give a concise and helpful response.
      If you are analyzing an image of a receipt, extract the items, quantities, and prices, and categorize the expense.
      `,
  },
);

/**
 * Defines the main Genkit flow.
 * A flow is an executable, server-side function that orchestrates AI model calls and other logic.
 * This flow takes the user's input, calls the defined prompt, and returns the structured output.
 */
const advisorFlow = ai.defineFlow(
  {
    name: 'advisorFlow',
    inputSchema: AdvisorInputSchema,
    outputSchema: AdvisorOutputSchema,
  },
  async (input) => {
    // Determine if the query suggests a need for financial data.
    const requiresFinancialAnalysis = /spending|habits|save money|financial situation|status|budget|salary/i.test(input.question);
    
    let promptPayload: object = { ...input };

    // If analysis is needed, call the tool first.
    if (requiresFinancialAnalysis) {
      const financialSummary = await getFinancialSummary.run({ userId: input.userId });

      if (!financialSummary.hasData) {
        // If there's no data, short-circuit and return a helpful message directly.
        // This is more efficient and reliable than asking the LLM to do it.
        return {
          response: "To provide an analysis, please add some income and expense data to your account first."
        };
      }
      
      // If there is data, add it to the payload for the AI to analyze.
      promptPayload = { ...input, financialSummary };
    }

    // Call the AI with the appropriate payload (with or without financial data).
    const { output } = await advisorPrompt(promptPayload);

    // The output is already parsed and validated against the output schema.
    // The non-null assertion (!) is safe here because if the model call failed,
    // Genkit would have already thrown an error.
    return output!;
  }
);

/**
 * An exported wrapper function that provides a clean, callable interface to the Genkit flow.
 * This is the function that the frontend component will import and call.
 *
 * @param {AdvisorInput} input - The user's input, matching the AdvisorInput schema.
 * @returns {Promise<AdvisorOutput>} A promise that resolves to the structured output from the AI.
 */
export async function askAdvisor(input: AdvisorInput): Promise<AdvisorOutput> {
  return await advisorFlow(input);
}
