/**
 * @file src/ai/genkit.ts
 * @fileoverview This file initializes and configures the Genkit AI toolkit for the application.
 * It sets up the necessary plugins, specifically the Google AI plugin, to interact with Google's
 * generative AI models (e.g., Gemini). It exports a configured `ai` instance that can be
 * used throughout the application to define and run AI flows, prompts, and tools.
 */
'use strict';

import { genkit, type Plugin } from 'genkit';
import { googleAI, type GoogleAIGenerativeAI } from '@genkit-ai/google-genai';

// Array of plugins to be loaded by Genkit.
const plugins: Plugin<any>[] = [];

// Check if the GEMINI_API_KEY environment variable is set.
// If it is, configure and add the Google AI plugin.
if (process.env.GEMINI_API_KEY) {
  plugins.push(
    googleAI({
      // The API key is implicitly read from the GEMINI_API_KEY environment variable.
    }) as Plugin<GoogleAIGenerativeAI>
  );
} else {
  // Log a warning if the API key is not found.
  console.warn(
    'GEMINI_API_KEY environment variable not found, Google AI plugin will not be configured.'
  );
}

/**
 * A globally accessible, configured Genkit instance.
 * This object is used to define flows, prompts, and other Genkit functionalities.
 * It is initialized with the plugins defined above.
 */
export const ai = genkit({
  plugins,
});
