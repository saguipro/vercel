/**
 * @file src/components/financial-overview.tsx
 * @fileoverview This component is responsible for fetching and displaying income transactions.
 * It includes a button to add new income and a list of existing income entries.
 */
'use client';

import { useState } from 'react';
import { useCollection, useFirebase, useMemoFirebase } from '@/firebase';
import { collection, query, orderBy, doc, deleteDoc } from 'firebase/firestore';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Loader2, Trash2, Plus } from 'lucide-react';
import AddTransactionDialog from './add-transaction-dialog';
import { useToast } from '@/hooks/use-toast';
import { FirestorePermissionError } from '@/firebase/errors';
import { errorEmitter } from '@/firebase/error-emitter';

/**
 * Defines the shape of a transaction object.
 */
export interface Transaction {
  id: string;
  category: string;
  amount: number;
  date: string;
  description?: string;
  userId: string;
  type: 'income' | 'expense';
}

/**
 * A reusable component to display a list of transactions.
 *
 * @param {object} props - The component props.
 * @param {string} props.title - The title for the transaction list card.
 * @param {Transaction[] | null} props.transactions - The array of transactions to display.
 * @param {boolean} props.isLoading - Loading state for the data.
 * @param {'income' | 'expense'} props.type - The type of transactions being displayed.
 * @returns {JSX.Element} A card component with a list of transactions.
 */
const TransactionList = ({
  title,
  transactions,
  isLoading,
  type,
}: {
  title: string;
  transactions: Transaction[] | null;
  isLoading: boolean;
  type: 'income' | 'expense';
}) => {
  const total = transactions?.reduce((acc, t) => acc + t.amount, 0) || 0;
  const currencyFormatter = new Intl.NumberFormat('en-IL', {
    style: 'currency',
    currency: 'ILS',
  });
  const { firestore, user } = useFirebase();
  const { toast } = useToast();

  const handleDelete = async (transactionId: string, collectionName: 'incomes' | 'expenses') => {
    if (!firestore || !user) return;

    const docRef = doc(firestore, 'users', user.uid, collectionName, transactionId);
    
    deleteDoc(docRef)
      .then(() => {
        toast({ title: 'Transaction Deleted', description: 'The transaction has been removed.' });
      })
      .catch((err) => {
        const permissionError = new FirestorePermissionError({
          path: docRef.path,
          operation: 'delete',
        });
        errorEmitter.emit('permission-error', permissionError);
      });
  };


  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading && <div className="flex justify-center p-4"><Loader2 className="mx-auto my-4 h-6 w-6 animate-spin" /></div>}
        {!isLoading && (!transactions || transactions.length === 0) && (
          <p className="text-sm text-center text-muted-foreground p-4">No transactions yet.</p>
        )}
        {transactions && transactions.length > 0 && (
          <div className="space-y-4">
            <ul className="max-h-60 space-y-3 overflow-y-auto pr-2">
              {transactions.map(t => (
                <li key={t.id} className="flex items-center justify-between text-sm group">
                  <div className="flex-1 flex items-start gap-2">
                     <div className="flex flex-col">
                      <span className="font-medium">{t.category}</span>
                      {t.description && (
                        <span className="text-xs text-muted-foreground">{t.description}</span>
                      )}
                      <span className="text-xs text-muted-foreground">{new Date(t.date + 'T00:00:00').toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-semibold ${
                        type === 'income'
                          ? 'text-green-600'
                          : 'text-red-600'
                      }`}
                    >
                      {type === 'income' ? '+' : '-'}{currencyFormatter.format(t.amount)}
                    </span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => handleDelete(t.id, type === 'income' ? 'incomes' : 'expenses')}
                    >
                        <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
            <div className="flex justify-between border-t pt-2 font-bold">
              <span>Total</span>
              <span>{currencyFormatter.format(total)}</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

/**
 * The main component for displaying the user's income overview.
 * It fetches income and renders all related components.
 *
 * @returns {JSX.Element} The FinancialOverview component.
 */
export default function FinancialOverview() {
  const { firestore, user } = useFirebase();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  // Memoized query for user's income documents, ordered by date descending.
  const incomesQuery = useMemoFirebase(
    () =>
      firestore && user
        ? query(collection(firestore, 'users', user.uid, 'incomes'), orderBy('date', 'desc'))
        : null,
    [firestore, user]
  );
  
  const { data: incomes, isLoading: incomesLoading } =
    useCollection<Omit<Transaction, 'type'>>(incomesQuery);
  
  const incomesWithType: Transaction[] | null = incomes
    ? incomes.map(i => ({ ...i, type: 'income' }))
    : null;
    
  const isLoading = incomesLoading;

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <AddTransactionDialog
          isOpen={isAddDialogOpen}
          onOpenChange={setIsAddDialogOpen}
          defaultType="income"
        >
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add Income
          </Button>
        </AddTransactionDialog>
      </div>
      <TransactionList
        title="Recent Income"
        transactions={incomesWithType}
        isLoading={isLoading}
        type="income"
      />
    </div>
  );
}
