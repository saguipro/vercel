/**
 * @file src/components/investments-overview.tsx
 * @fileoverview This component displays a static overview of the user's investment portfolio.
 * It includes metric cards, a portfolio holdings table, and a performance chart.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Plus, MoreHorizontal } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"


function MetricCard({ title, value, change, isPositive }: { title: string; value: string; change: string; isPositive: boolean; }) {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <p className={`text-xs ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                    {change} from last month
                </p>
            </CardContent>
        </Card>
    );
}

function PortfolioHoldings() {
    const holdings = [
        { symbol: 'AAPL', name: 'Apple Inc.', quantity: 50, price: 172.25, value: 8612.50, change: 1.5, isPositive: true },
        { symbol: 'GOOGL', name: 'Alphabet Inc.', quantity: 20, price: 139.74, value: 2794.80, change: -0.8, isPositive: false },
        { symbol: 'MSFT', name: 'Microsoft Corp.', quantity: 35, price: 370.95, value: 12983.25, change: 2.1, isPositive: true },
        { symbol: 'TSLA', name: 'Tesla, Inc.', quantity: 25, price: 234.30, value: 5857.50, change: -3.2, isPositive: false },
        { symbol: 'VTI', name: 'Vanguard Total Stock Market ETF', quantity: 100, price: 232.50, value: 23250.00, change: 0.5, isPositive: true },
    ];
    
    return (
         <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Portfolio Holdings</CardTitle>
                    <CardDescription>A list of your current investments.</CardDescription>
                </div>
                <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Holding
                </Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Symbol</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead className="text-right">Quantity</TableHead>
                            <TableHead className="text-right">Price</TableHead>
                            <TableHead className="text-right">Market Value</TableHead>
                            <TableHead className="text-right">Day's Change</TableHead>
                            <TableHead><span className="sr-only">Actions</span></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {holdings.map((holding) => (
                            <TableRow key={holding.symbol}>
                                <TableCell className="font-medium">{holding.symbol}</TableCell>
                                <TableCell>{holding.name}</TableCell>
                                <TableCell className="text-right">{holding.quantity}</TableCell>
                                <TableCell className="text-right">₪{holding.price.toFixed(2)}</TableCell>
                                <TableCell className="text-right">₪{holding.value.toFixed(2)}</TableCell>
                                <TableCell className={`text-right ${holding.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                                    {holding.isPositive ? '+' : ''}{holding.change.toFixed(1)}%
                                </TableCell>
                                <TableCell className="text-right">
                                     <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-8 w-8 p-0" aria-label={`Actions for ${holding.name}`}>
                                            <span className="sr-only">Open menu</span>
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem>View Details</DropdownMenuItem>
                                            <DropdownMenuItem>Trade</DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

export default function InvestmentsOverview() {
  const investmentMetrics = {
    portfolioValue: 53498.05,
    totalReturn: 4201.15,
    dayChange: -152.40,
  };
    
  return (
    <div className="space-y-8">
      <section>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <MetricCard 
                  title="Portfolio Value" 
                  value={`₪${investmentMetrics.portfolioValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`}
                  change="+8.5%"
                  isPositive={true}
              />
              <MetricCard 
                  title="Total Return" 
                  value={`₪${investmentMetrics.totalReturn.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`}
                  change="+1.2%"
                  isPositive={true}
              />
               <MetricCard 
                  title="Day's Performance" 
                  value={`₪${investmentMetrics.dayChange.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`}
                  change="-0.28%"
                  isPositive={false}
              />
          </div>
      </section>
      <section>
        <PortfolioHoldings />
      </section>
    </div>
  );
}

    