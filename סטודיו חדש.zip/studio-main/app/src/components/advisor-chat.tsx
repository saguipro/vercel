/**
 * @file src/components/advisor-chat.tsx
 * @fileoverview This component provides the user interface for interacting with the AI financial advisor.
 * It handles chat history, user input, image uploads, and communication with the Genkit flow.
 */
'use client';

import { useState, useRef, useEffect, FormEvent } from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Loader2, Bot, User, Paperclip, X, Send } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useUser } from '@/firebase';
import { useLanguage } from '@/contexts/language-context';
import { askAdvisor, AdvisorOutput } from '@/ai/flows/advisor-flow';

/**
 * Represents a single message in the chat interface.
 * Can be from either the 'user' or the 'bot'.
 */
interface ChatMessage {
  type: 'user' | 'bot';
  text: string;
  userImage?: string;
  botResponse?: AdvisorOutput;
}

/**
 * Represents an image file selected by the user for upload.
 * Contains the file object and its data URI representation.
 */
interface ImageFile {
  file: File;
  dataUri: string;
}

/**
 * The main component for the AI advisor chat interface.
 */
export default function AdvisorChat() {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [imageFile, setImageFile] = useState<ImageFile | null>(null);
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { user } = useUser();
  const { t } = useLanguage();

  // Effect to automatically scroll the chat history to the latest message.
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, loading]);

  /**
   * Processes the file selected by the user.
   * Validates file size and converts it to a data URI for the API.
   * @param e - The change event from the file input element.
   */
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) { // 4MB limit
        toast({
            variant: 'destructive',
            title: 'File too large',
            description: 'Please upload an image smaller than 4MB.',
        });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageFile({ file, dataUri: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  /**
   * Handles the submission of the user's query (text and/or image).
   * @param e - The form submission event.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if ((!query.trim() && !imageFile) || loading || !user) return;

    const currentQuery = query;
    const currentImageFile = imageFile;

    const userMessage: ChatMessage = {
      type: 'user',
      text: currentQuery,
      userImage: currentImageFile ? URL.createObjectURL(currentImageFile.file) : undefined,
    };
    setHistory((prev) => [...prev, userMessage]);
    setLoading(true);
    setQuery('');
    setImageFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }

    try {
      const result = await askAdvisor({
        userId: user.uid,
        question: currentQuery,
        image: currentImageFile?.dataUri,
      });

      const botMessage: ChatMessage = { 
        type: 'bot', 
        text: result.response,
        botResponse: result
      };
      setHistory((prev) => [...prev, botMessage]);

    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: t('errorTitle'),
        description: err.message || t('unexpectedError'),
      });
      // Revert optimistic UI update on failure
      setHistory((prev) => prev.slice(0, -1));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-150px)]">
      <div
        ref={scrollRef}
        className="flex-1 space-y-6 overflow-y-auto pr-4 -mr-4"
      >
        {history.length === 0 && !loading && (
          <div className="flex h-full flex-col items-center justify-center text-center text-muted-foreground">
            <Bot className="mb-4 h-16 w-16" />
            <h2 className="text-3xl font-semibold text-foreground">
              {t('welcomeTitle')}
            </h2>
            <p className="mt-2">{t('welcomeMessage')}</p>
          </div>
        )}

        {history.map((item, index) => (
          <div
            key={index}
            className={`flex items-start gap-4 ${
              item.type === 'user' ? 'justify-end' : ''
            }`}
          >
            {item.type === 'bot' && (
              <Bot className="h-8 w-8 flex-shrink-0 text-primary" />
            )}
            <div
              className={`flex flex-col gap-2 ${
                item.type === 'user' ? 'items-end' : 'items-start'
              }`}
            >
              {item.type === 'user' ? (
                 <div className="max-w-lg rounded-lg bg-primary p-3 text-primary-foreground shadow-md">
                  {item.userImage && (
                    <div className="mb-2 overflow-hidden rounded-lg">
                      <Image
                        src={item.userImage}
                        alt="User upload"
                        width={300}
                        height={200}
                        className="object-cover"
                      />
                    </div>
                  )}
                  {item.text && <p>{item.text}</p>}
                </div>
              ) : (
                <Card className="max-w-lg bg-card shadow-md">
                  <CardContent className="p-4">
                    <p className="whitespace-pre-wrap">{item.text}</p>
                    {item.botResponse?.imageUrl && (
                      <div className="mt-3 overflow-hidden rounded-lg border">
                        <Image
                          src={item.botResponse.imageUrl}
                          alt="Generated image"
                          data-ai-hint="finance illustration"
                          width={500}
                          height={300}
                          className="object-cover"
                        />
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
            </div>
            {item.type === 'user' && (
              <User className="h-8 w-8 flex-shrink-0 text-muted-foreground" />
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-start gap-4">
            <Bot className="h-8 w-8 flex-shrink-0 text-primary" />
            <div className="flex items-center space-x-2 rounded-lg bg-card p-3 shadow-md">
              <Loader2 className="h-5 w-5 animate-spin" />
              <p className="text-muted-foreground">{t('thinking')}...</p>
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 border-t pt-6">
        {imageFile && (
          <div className="relative mb-4 w-40">
            <Image
              src={URL.createObjectURL(imageFile.file)}
              alt="Image preview"
              width={160}
              height={100}
              className="rounded-lg object-cover"
            />
            <Button
              variant="destructive"
              size="icon"
              className="absolute right-1 top-1 h-6 w-6"
              onClick={() => {
                setImageFile(null);
                if (fileInputRef.current) fileInputRef.current.value = '';
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
        <form onSubmit={handleSubmit} className="flex items-center space-x-3">
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            disabled={loading}
            className="flex-shrink-0"
          >
            <Paperclip className="h-5 w-5" />
          </Button>
           <Input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
          />
          <Input
            type="text"
            placeholder={t('inputPlaceholder')}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={loading}
            className="flex-1 rounded-full px-5"
          />
          <Button
            type="submit"
            disabled={loading || (!query.trim() && !imageFile)}
            className="rounded-full"
            size="icon"
          >
            {loading ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Send className="h-5 w-5" />
            )}
            <span className="sr-only">{t('sendButton')}</span>
          </Button>
        </form>
      </div>
    </div>
  );
}