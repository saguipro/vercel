/**
 * @file src/components/goals-overview.tsx
 * @fileoverview This component provides a fully dynamic and interactive interface for managing financial goals.
 * It allows users to view, add, edit, and delete their goals, with all data persisted in Firestore.
 */
'use client';

import { useState, FormEvent, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { Progress } from './ui/progress';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Plus, Target, Loader2, Pencil, Trash2 } from 'lucide-react';
import { useFirebase, useCollection, useMemoFirebase } from '@/firebase';
import { collection, query, doc, setDoc, deleteDoc, orderBy } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { FirestorePermissionError } from '@/firebase/errors';
import { errorEmitter } from '@/firebase/error-emitter';
import { v4 as uuidv4 } from 'uuid';

/**
 * Defines the shape of a Goal object as stored in Firestore and used in the component.
 */
export interface Goal {
  id: string;
  userId: string;
  name: string;
  description: string;
  targetAmount: number;
  currentAmount: number;
}

/**
 * The main component for displaying and managing a user's financial goals.
 * Fetches goals from Firestore and provides full CRUD (Create, Read, Update, Delete) functionality.
 */
export default function GoalsOverview() {
    const { firestore, user } = useFirebase();
    const { toast } = useToast();

    // State for managing the dialog (modal) for adding/editing goals
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
    
    // State for the form fields within the dialog
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [targetAmount, setTargetAmount] = useState('');
    const [currentAmount, setCurrentAmount] = useState('');
    
    const [isSubmitting, setIsSubmitting] = useState(false);
    const nameInputRef = useRef<HTMLInputElement>(null);

    const currencyFormatter = new Intl.NumberFormat('en-IL', {
        style: 'currency',
        currency: 'ILS',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    });
    
    // Memoized query to fetch the user's goals from Firestore, ordered by name.
    const goalsQuery = useMemoFirebase(
        () => 
            firestore && user 
                ? query(collection(firestore, 'users', user.uid, 'goals'), orderBy('name'))
                : null,
        [firestore, user]
    );

    const { data: goals, isLoading: goalsLoading } = useCollection<Goal>(goalsQuery);

    // Focus the first input field when the dialog opens.
    useEffect(() => {
        if (isDialogOpen) {
          setTimeout(() => {
            nameInputRef.current?.focus();
          }, 100);
        }
      }, [isDialogOpen]);

    /**
     * Opens the dialog in "add" mode, clearing all form fields.
     */
    const handleAddNew = () => {
        setEditingGoal(null);
        setName('');
        setDescription('');
        setTargetAmount('');
        setCurrentAmount('');
        setIsDialogOpen(true);
    };

    /**
     * Opens the dialog in "edit" mode, pre-filling the form with the selected goal's data.
     * @param goal The goal object to be edited.
     */
    const handleEdit = (goal: Goal) => {
        setEditingGoal(goal);
        setName(goal.name);
        setDescription(goal.description);
        setTargetAmount(String(goal.targetAmount));
        setCurrentAmount(String(goal.currentAmount));
        setIsDialogOpen(true);
    };

    /**
     * Deletes a goal document from Firestore after user confirmation.
     * @param goalId The ID of the goal to delete.
     */
    const handleDelete = async (goalId: string) => {
        if (!firestore || !user) return;
        
        const docRef = doc(firestore, 'users', user.uid, 'goals', goalId);
        
        deleteDoc(docRef)
            .then(() => {
                toast({ title: 'Goal Deleted', description: 'The financial goal has been removed.' });
            })
            .catch((err) => {
                const permissionError = new FirestorePermissionError({
                  path: docRef.path,
                  operation: 'delete',
                });
                errorEmitter.emit('permission-error', permissionError);
            });
    };

    /**
     * Handles the form submission for both creating and updating a goal.
     * @param e The form submission event.
     */
    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();
        if (!firestore || !user || !name.trim() || !targetAmount) {
          toast({ variant: 'destructive', title: 'Missing Fields', description: 'Please fill out all required fields.' });
          return;
        }
        setIsSubmitting(true);
    
        const goalData = {
          userId: user.uid,
          name: name.trim(),
          description: description.trim(),
          targetAmount: parseFloat(targetAmount),
          currentAmount: parseFloat(currentAmount || '0'),
        };
    
        let docRef;
        let operation: 'create' | 'update' = 'create';
        let dataToSend: Goal;
    
        if (editingGoal) { // Update existing goal
          operation = 'update';
          docRef = doc(firestore, 'users', user.uid, 'goals', editingGoal.id);
          dataToSend = { ...goalData, id: editingGoal.id };

           setDoc(docRef, dataToSend, { merge: true })
            .then(() => {
              toast({ title: 'Goal Updated', description: 'Your goal has been successfully updated.' });
              setIsDialogOpen(false);
            })
            .catch((err) => {
              const permissionError = new FirestorePermissionError({
                path: docRef.path,
                operation,
                requestResourceData: dataToSend,
              });
              errorEmitter.emit('permission-error', permissionError);
            })
            .finally(() => setIsSubmitting(false));

        } else { // Create new goal
          const newId = uuidv4();
          docRef = doc(firestore, 'users', user.uid, 'goals', newId);
          dataToSend = { ...goalData, id: newId };
          
          setDoc(docRef, dataToSend)
            .then(() => {
              toast({ title: 'Goal Created', description: 'Your new financial goal has been set.' });
              setIsDialogOpen(false);
            })
            .catch((err) => {
               const permissionError = new FirestorePermissionError({
                path: docRef.path,
                operation,
                requestResourceData: dataToSend,
              });
              errorEmitter.emit('permission-error', permissionError);
            })
            .finally(() => setIsSubmitting(false));
        }
    };


    return (
        <>
            <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                        <CardTitle className="flex items-center gap-2">
                            <Target className="h-6 w-6" />
                            Financial Goals
                        </CardTitle>
                        <CardDescription>Your progress towards your financial targets.</CardDescription>
                    </div>
                    <Button size="sm" onClick={handleAddNew}>
                        <Plus className="mr-2 h-4 w-4" /> Add Goal
                    </Button>
                </CardHeader>
                <CardContent>
                    {goalsLoading ? (
                        <div className="flex justify-center items-center p-8">
                            <Loader2 className="h-8 w-8 animate-spin" />
                        </div>
                    ) : goals && goals.length > 0 ? (
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {goals.map((goal) => (
                                <Card key={goal.id} className="p-4 flex flex-col justify-between relative group">
                                    <div className="absolute top-2 right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleEdit(goal)}>
                                            <Pencil className="h-4 w-4" />
                                        </Button>
                                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => handleDelete(goal.id)}>
                                            <Trash2 className="h-4 w-4 text-destructive" />
                                        </Button>
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-lg pr-20">{goal.name}</h3>
                                        <p className="text-sm text-muted-foreground mb-3 h-10">{goal.description}</p>
                                        <Progress value={(goal.currentAmount / goal.targetAmount) * 100} className="h-3" />
                                    </div>
                                    <div className="mt-3 text-sm flex justify-between items-end">
                                        <span className="font-semibold text-primary">
                                            {currencyFormatter.format(goal.currentAmount)}
                                        </span>
                                        <span className="text-xs text-muted-foreground">
                                            Target: {currencyFormatter.format(goal.targetAmount)}
                                        </span>
                                    </div>
                                </Card>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center p-8">
                            <p className="text-muted-foreground">You haven't set any financial goals yet.</p>
                            <Button variant="link" onClick={handleAddNew} className="mt-2">Create your first goal</Button>
                        </div>
                    )}
                </CardContent>
            </Card>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogContent className="sm:max-w-[480px]">
                <DialogHeader>
                    <DialogTitle>{editingGoal ? 'Edit Goal' : 'Add New Goal'}</DialogTitle>
                    <DialogDescription>
                        Define your financial goal and track your progress.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="goal-name" className="text-right">Name</Label>
                            <Input id="goal-name" ref={nameInputRef} value={name} onChange={(e) => setName(e.target.value)} className="col-span-3" placeholder="e.g., New Car Fund" required disabled={isSubmitting} />
                        </div>
                         <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="goal-desc" className="text-right">Description</Label>
                            <Input id="goal-desc" value={description} onChange={(e) => setDescription(e.target.value)} className="col-span-3" placeholder="e.g., Saving for a new family car" disabled={isSubmitting} />
                        </div>
                         <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="current-amount" className="text-right">Current</Label>
                            <Input id="current-amount" type="number" value={currentAmount} onChange={(e) => setCurrentAmount(e.target.value)} className="col-span-3" placeholder="0.00" required disabled={isSubmitting} />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="target-amount" className="text-right">Target</Label>
                            <Input id="target-amount" type="number" value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} className="col-span-3" placeholder="0.00" required disabled={isSubmitting} />
                        </div>
                    </div>
                    <DialogFooter>
                    <DialogClose asChild>
                        <Button type="button" variant="secondary" disabled={isSubmitting}>Cancel</Button>
                    </DialogClose>
                    <Button type="submit" disabled={isSubmitting}>
                        {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Save Goal'}
                    </Button>
                    </DialogFooter>
                </form>
                </DialogContent>
            </Dialog>
        </>
    );
}
