/**
 * @file src/components/scenario-analysis-overview.tsx
 * @fileoverview This component displays a fully interactive UI for the "what-if" scenario analysis tool.
 * It allows users to input a financial scenario, which is then sent to the AI advisor for analysis.
 */
'use client';

import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from './ui/card';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { BrainCircuit, Loader2 } from 'lucide-react';
import { useUser } from '@/firebase';
import { askAdvisor } from '@/ai/flows/advisor-flow';
import { useToast } from '@/hooks/use-toast';
import { useLanguage } from '@/contexts/language-context';

export default function ScenarioAnalysisOverview() {
    const [scenario, setScenario] = useState('');
    const [analysis, setAnalysis] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const { user } = useUser();
    const { toast } = useToast();
    const { t } = useLanguage();

    const handleAnalyze = async () => {
        if (!scenario.trim() || !user) {
            toast({
                variant: 'destructive',
                title: 'Missing Information',
                description: 'Please describe a scenario to analyze.',
            });
            return;
        }

        setIsLoading(true);
        setAnalysis('');

        try {
            // Frame the question for the AI to make it clear this is a scenario analysis
            const fullQuestion = `Analyze the following financial scenario for me: "${scenario}". Based on my financial data, what would be the likely impact on my savings, budget, and overall financial health?`;
            
            const result = await askAdvisor({
                userId: user.uid,
                question: fullQuestion,
            });
            
            setAnalysis(result.response);

        } catch (error: any) {
            toast({
                variant: 'destructive',
                title: t('errorTitle'),
                description: error.message || t('unexpectedError'),
            });
        } finally {
            setIsLoading(false);
        }
    };


    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
                <CardHeader>
                    <CardTitle>Define a Scenario</CardTitle>
                    <CardDescription>
                        Describe a financial "what-if" scenario. For example, "What if my salary increases by 15% next year, but my rent also goes up by 10%?"
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="grid w-full items-center gap-4">
                        <div className="flex flex-col space-y-1.5">
                            <Label htmlFor="scenario-description">Scenario Description</Label>
                            <textarea
                                id="scenario-description"
                                placeholder="e.g., What if I start a side hustle that brings in an extra ₪1,500 per month?"
                                className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                value={scenario}
                                onChange={(e) => setScenario(e.target.value)}
                                disabled={isLoading}
                            />
                        </div>
                    </div>
                </CardContent>
                <CardFooter>
                    <Button className="w-full" onClick={handleAnalyze} disabled={isLoading}>
                        {isLoading ? (
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                            <BrainCircuit className="mr-2 h-4 w-4" />
                        )}
                        Analyze Scenario
                    </Button>
                </CardFooter>
            </Card>

            <Card className="flex flex-col">
                <CardHeader>
                    <CardTitle>AI-Powered Analysis</CardTitle>
                    <CardDescription>
                        The projected impact of your scenario based on your current financial data.
                    </CardDescription>
                </CardHeader>
                <CardContent className="flex-grow flex items-center justify-center">
                    {isLoading ? (
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    ) : analysis ? (
                        <div className="text-sm whitespace-pre-wrap">{analysis}</div>
                    ) : (
                        <div className="text-center text-muted-foreground">
                            <p>Analysis results will be displayed here.</p>
                        </div>
                    )}
                </CardContent>
                 <CardFooter>
                    <p className="text-xs text-muted-foreground">
                        Note: This is a projection and not financial advice. Results are based on AI analysis of your provided data.
                    </p>
                </CardFooter>
            </Card>
        </div>
    );
}
