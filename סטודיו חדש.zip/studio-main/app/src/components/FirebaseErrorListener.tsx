/**
 * @file src/components/FirebaseErrorListener.tsx
 * @fileoverview This component acts as a global sink for Firestore permission errors.
 * It subscribes to the `errorEmitter` and, upon receiving an error, throws it.
 * This is a crucial pattern because it allows asynchronous errors (from `onSnapshot`
 * or `.catch()` blocks) to be caught by Next.js's global error handling mechanisms
 * (like `global-error.js` or the development error overlay), which they normally wouldn't be.
 */
'use client';

import { useState, useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

/**
 * An invisible component that listens for globally emitted 'permission-error' events
 * and throws them to be caught by Next.js's error boundary.
 */
export function FirebaseErrorListener() {
  const [error, setError] = useState<FirestorePermissionError | null>(null);

  useEffect(() => {
    const handleError = (error: FirestorePermissionError) => {
      // Set the error in component state to trigger a re-render.
      setError(error);
    };

    // Subscribe to the specific 'permission-error' event.
    errorEmitter.on('permission-error', handleError);

    // Unsubscribe on unmount to prevent memory leaks.
    return () => {
      errorEmitter.off('permission-error', handleError);
    };
  }, []);

  // If an error has been set in the state, throw it during the render cycle.
  // This is the key step that allows Next.js to catch the async error.
  if (error) {
    throw error;
  }

  // This component renders nothing to the DOM.
  return null;
}
