/**
 * @file src/components/budget-tracker.tsx
 * @fileoverview This component visualizes the user's spending against their set monthly budgets.
 * It displays a progress bar for each budgeted category, showing how much has been spent.
 */
'use client';

import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from './ui/card';
import { Progress } from './ui/progress';
import { Loader2 } from 'lucide-react';
import type { Budget } from './budget-manager';
import type { Transaction } from './financial-overview';

interface BudgetTrackerProps {
  budgets: Budget[] | null;
  expenses: Transaction[] | null;
  isLoading: boolean;
}

interface TrackedBudget {
  category: string;
  budgeted: number;
  spent: number;
  percentage: number;
}

/**
 * A component that displays progress bars for each monthly budget,
 * tracking current spending against the allocated amount.
 *
 * @param {BudgetTrackerProps} props - Component props.
 * @returns {JSX.Element} The budget tracking component.
 */
export default function BudgetTracker({ budgets, expenses, isLoading }: BudgetTrackerProps) {
  const now = new Date();
  const currentMonth = now.getMonth() + 1;
  const currentYear = now.getFullYear();

  const currencyFormatter = new Intl.NumberFormat('en-IL', {
    style: 'currency',
    currency: 'ILS',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });

  /**
   * Memoized calculation to process and aggregate budget and expense data.
   * It matches expenses to their respective budgets for the current month
   * and calculates spending percentages.
   */
  const trackedBudgets: TrackedBudget[] = useMemo(() => {
    if (!budgets || !expenses) {
      return [];
    }

    const currentMonthBudgets = budgets.filter(
      b => b.year === currentYear && b.month === currentMonth
    );

    const expensesByCategory = expenses.reduce((acc, expense) => {
      // Only consider expenses from the current month
      const expenseDate = new Date(expense.date + 'T00:00:00');
      if (expenseDate.getFullYear() === currentYear && expenseDate.getMonth() + 1 === currentMonth) {
        if (!acc[expense.category]) {
          acc[expense.category] = 0;
        }
        acc[expense.category] += expense.amount;
      }
      return acc;
    }, {} as Record<string, number>);

    return currentMonthBudgets.map(budget => {
      const spent = expensesByCategory[budget.category] || 0;
      const percentage = budget.amount > 0 ? (spent / budget.amount) * 100 : 0;
      return {
        category: budget.category,
        budgeted: budget.amount,
        spent,
        percentage,
      };
    });
  }, [budgets, expenses, currentYear, currentMonth]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Budget Progress</CardTitle>
        <CardDescription>Your spending progress for this month's budgets.</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : trackedBudgets.length > 0 ? (
          <div className="space-y-4">
            {trackedBudgets.map(item => (
              <div key={item.category}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium">{item.category}</span>
                  <span className="text-muted-foreground">
                    {currencyFormatter.format(item.spent)} / {currencyFormatter.format(item.budgeted)}
                  </span>
                </div>
                <Progress value={item.percentage} aria-label={`Spending for ${item.category}: ${item.percentage.toFixed(0)}%`} />
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-sm text-muted-foreground p-4">
            No budgets set for this month. Add a budget to track your progress!
          </p>
        )}
      </CardContent>
    </Card>
  );
}

    