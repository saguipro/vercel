/**
 * @file src/components/crypto-overview.tsx
 * @fileoverview This component displays a static overview of the user's crypto portfolio.
 * It includes metric cards, a portfolio holdings table, and a performance chart.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { Button } from './ui/button';
import { Plus, MoreHorizontal } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"


function MetricCard({ title, value, change, isPositive }: { title: string; value: string; change: string; isPositive: boolean; }) {
    return (
        <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{title}</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="text-2xl font-bold">{value}</div>
                <p className={`text-xs ${isPositive ? 'text-green-600' : 'text-red-600'}`}>
                    {change} from last 24h
                </p>
            </CardContent>
        </Card>
    );
}

function CryptoHoldings() {
    const holdings = [
        { symbol: 'BTC', name: 'Bitcoin', quantity: 0.5, price: 68000, value: 34000, change: 2.5, isPositive: true },
        { symbol: 'ETH', name: 'Ethereum', quantity: 10, price: 3500, value: 35000, change: -1.2, isPositive: false },
        { symbol: 'SOL', name: 'Solana', quantity: 150, price: 170, value: 25500, change: 5.1, isPositive: true },
    ];
    
    return (
         <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <div>
                    <CardTitle>Crypto Holdings</CardTitle>
                    <CardDescription>Your cryptocurrency portfolio.</CardDescription>
                </div>
                <Button size="sm">
                    <Plus className="mr-2 h-4 w-4" /> Add Asset
                </Button>
            </CardHeader>
            <CardContent>
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Symbol</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead className="text-right">Quantity</TableHead>
                            <TableHead className="text-right">Price</TableHead>
                            <TableHead className="text-right">Market Value</TableHead>
                            <TableHead className="text-right">24h Change</TableHead>
                            <TableHead><span className="sr-only">Actions</span></TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {holdings.map((holding) => (
                            <TableRow key={holding.symbol}>
                                <TableCell className="font-medium">{holding.symbol}</TableCell>
                                <TableCell>{holding.name}</TableCell>
                                <TableCell className="text-right">{holding.quantity}</TableCell>
                                <TableCell className="text-right">₪{holding.price.toFixed(2)}</TableCell>
                                <TableCell className="text-right">₪{holding.value.toFixed(2)}</TableCell>
                                <TableCell className={`text-right ${holding.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                                    {holding.isPositive ? '+' : ''}{holding.change.toFixed(1)}%
                                </TableCell>
                                <TableCell className="text-right">
                                     <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                        <Button variant="ghost" className="h-8 w-8 p-0" aria-label={`Actions for ${holding.name}`}>
                                            <span className="sr-only">Open menu</span>
                                            <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                            <DropdownMenuItem>View Details</DropdownMenuItem>
                                            <DropdownMenuItem>Trade</DropdownMenuItem>
                                        </DropdownMenuContent>
                                    </DropdownMenu>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    );
}

export default function CryptoOverview() {
  const cryptoMetrics = {
    portfolioValue: 94500,
    dayChange: 1250.75,
  };
    
  return (
    <div className="space-y-8">
      <section>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <MetricCard 
                  title="Portfolio Value" 
                  value={`₪${cryptoMetrics.portfolioValue.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`}
                  change="+1.34%"
                  isPositive={true}
              />
               <MetricCard 
                  title="24h Performance" 
                  value={`₪${cryptoMetrics.dayChange.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`}
                  change="+1.34%"
                  isPositive={true}
              />
          </div>
      </section>
      <section>
        <CryptoHoldings />
      </section>
    </div>
  );
}

    