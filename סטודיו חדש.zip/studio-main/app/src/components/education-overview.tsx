/**
 * @file src/components/education-overview.tsx
 * @fileoverview This component displays a static overview of financial education topics.
 */
'use client';

import { Card, CardHeader, CardTitle, CardContent, CardDescription } from './ui/card';
import { BookOpen } from 'lucide-react';

export default function EducationOverview() {
    const topics = [
        { 
            title: 'The Basics of Budgeting', 
            description: 'Learn how to create and stick to a personal budget to manage your money effectively.',
            category: 'Budgeting',
            href: '#'
        },
        { 
            title: 'Introduction to Investing', 
            description: 'Understand the fundamentals of investing in stocks, bonds, and other assets.',
            category: 'Investing',
            href: '#'
        },
        { 
            title: 'Understanding Cryptocurrency', 
            description: 'A beginner\'s guide to what cryptocurrencies are and how they work.',
            category: 'Crypto',
            href: '#'
        },
        { 
            title: 'How to Build an Emergency Fund', 
            description: 'Discover the importance of having an emergency fund and how to build one.',
            category: 'Savings',
            href: '#'
        },
        { 
            title: 'Retirement Planning 101', 
            description: 'Start planning for your future with this introduction to retirement savings.',
            category: 'Planning',
            href: '#'
        },
        { 
            title: 'Explore AI Tools on Futurepedia', 
            description: 'Discover the latest AI tools for finance and more on Futurepedia.io.',
            category: 'AI Resources',
            href: 'https://www.futurepedia.io'
        },
    ];

    return (
        <div className="space-y-8">
            <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                        <BookOpen className="h-6 w-6" />
                        Learning Center
                    </CardTitle>
                    <CardDescription>
                        Expand your financial knowledge with these articles and guides.
                    </CardDescription>
                </CardHeader>
                <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {topics.map((topic, index) => (
                        <a href={topic.href} key={index} target={topic.href === '#' ? '_self' : '_blank'} rel="noopener noreferrer" className="block h-full">
                            <Card className="flex flex-col justify-between p-6 hover:shadow-lg transition-shadow cursor-pointer h-full">
                                <div>
                                    <p className="text-sm font-semibold text-primary mb-1">{topic.category}</p>
                                    <h3 className="font-bold text-lg mb-2">{topic.title}</h3>
                                    <p className="text-sm text-muted-foreground">{topic.description}</p>
                                </div>
                            </Card>
                        </a>
                    ))}
                </CardContent>
            </Card>
        </div>
    );
}
