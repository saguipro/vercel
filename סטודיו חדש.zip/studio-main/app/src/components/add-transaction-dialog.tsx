/**
 * @file src/components/add-transaction-dialog.tsx
 * @fileoverview This component provides a dialog form for users to add new income or expense transactions.
 * It handles form state, validation, and submission to Firestore.
 */
'use client';

import { useState, FormEvent, useEffect } from 'react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
  DialogTrigger,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { useFirebase } from '@/firebase';
import { addDoc, collection } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { FirestorePermissionError } from '@/firebase/errors';
import { errorEmitter } from '@/firebase/error-emitter';
import { v4 as uuidv4 } from 'uuid';
import { useLanguage } from '@/contexts/language-context';

interface AddTransactionDialogProps {
  children: React.ReactNode;
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
  defaultType?: 'income' | 'expense';
}

/**
 * A dialog form component to add a new income or expense transaction.
 *
 * @param {AddTransactionDialogProps} props The component props.
 * @returns {JSX.Element} The AddTransactionDialog component.
 */
export default function AddTransactionDialog({ 
    children, 
    isOpen,
    onOpenChange,
    defaultType = 'expense'
}: AddTransactionDialogProps) {
  const [type, setType] = useState<'income' | 'expense'>(defaultType);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const { t } = useLanguage();

  const { firestore, user } = useFirebase();
  const { toast } = useToast();

  useEffect(() => {
    setType(defaultType);
  }, [defaultType]);
  
  const resetForm = () => {
    setAmount('');
    setCategory('');
    setDescription('');
    setDate(new Date().toISOString().split('T')[0]);
  };

  /**
   * Handles the form submission to add a new transaction.
   *
   * @param {FormEvent} e - The form submission event.
   */
  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!firestore || !user || !amount || !category || !date) {
      toast({
        variant: 'destructive',
        title: t('missingFieldsTitle'),
        description: t('missingFieldsDesc'),
      });
      return;
    }
    setLoading(true);

    const transactionData = {
      id: uuidv4(),
      userId: user.uid,
      category,
      amount: parseFloat(amount),
      date,
      description,
    };

    const collectionName = type === 'income' ? 'incomes' : 'expenses';
    const collectionRef = collection(firestore, 'users', user.uid, collectionName);

    addDoc(collectionRef, transactionData)
      .then(() => {
        toast({
          title: t('transactionAddedTitle'),
          description: t(type === 'income' ? 'incomeAddedDesc' : 'expenseAddedDesc'),
        });
        resetForm();
        onOpenChange(false);
      })
      .catch((err) => {
        const permissionError = new FirestorePermissionError({
          path: collectionRef.path,
          operation: 'create',
          requestResourceData: transactionData,
        });

        errorEmitter.emit('permission-error', permissionError);
      })
      .finally(() => {
        setLoading(false);
      });
  };
  
  const handleOpenChange = (open: boolean) => {
    if (!open) {
        resetForm();
    }
    onOpenChange(open);
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
        <DialogTrigger asChild>{children}</DialogTrigger>
        <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
                <DialogTitle>{t('addTransactionTitle')}</DialogTitle>
                <DialogDescription>
                    {t('addTransactionDesc')}
                </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                    <Button
                    type="button"
                    variant={type === 'income' ? 'default' : 'outline'}
                    onClick={() => setType('income')}
                    >
                    {t('incomeLabel')}
                    </Button>
                    <Button
                    type="button"
                    variant={type === 'expense' ? 'default' : 'outline'}
                    onClick={() => setType('expense')}
                    >
                    {t('expensesLabel')}
                    </Button>
                </div>
                <div className="grid gap-2">
                    <Label htmlFor="amount">{t('amountLabel')}</Label>
                    <Input
                    id="amount"
                    type="number"
                    placeholder="0.00"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    disabled={loading}
                    />
                </div>
                <div className="grid gap-2">
                    <Label htmlFor="category">{t('categoryLabel')}</Label>
                    <Input
                    id="category"
                    type="text"
                    placeholder={type === 'income' ? t('categoryPlaceholderIncome') : t('categoryPlaceholderExpense')}
                    required
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    disabled={loading}
                    />
                </div>
                <div className="grid gap-2">
                    <Label htmlFor="description">{t('descriptionLabel')}</Label>
                    <Input
                    id="description"
                    type="text"
                    placeholder={t('descriptionPlaceholder')}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    disabled={loading}
                    />
                </div>
                <div className="grid gap-2">
                    <Label htmlFor="date">{t('dateLabel')}</Label>
                    <Input
                    id="date"
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    disabled={loading}
                    />
                </div>
                 <DialogFooter>
                    <DialogClose asChild>
                        <Button type="button" variant="secondary" disabled={loading}>
                        {t('cancelButton')}
                        </Button>
                    </DialogClose>
                    <Button type="submit" disabled={loading}>
                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : t('addTransactionButton')}
                    </Button>
                </DialogFooter>
            </form>
        </DialogContent>
    </Dialog>
  );
}
