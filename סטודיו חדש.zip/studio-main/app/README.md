# Family Finance App

This is a Next.js application built with Firebase, ShadCN, and Genkit for AI-powered financial advice.

## Deployment to Netlify

This project is configured for seamless deployment on Netlify.

### Prerequisites

*   A Netlify account.
*   Your project code pushed to a Git repository (GitHub, GitLab, Bitbucket).

### Step-by-Step Deployment

1.  **Log in to Netlify** and go to your team's Sites page.
2.  Click **"Add new site"** and select **"Import an existing project"**.
3.  **Connect to your Git provider** (e.g., GitHub) and authorize Netlify.
4.  **Select the repository** for this project.
5.  **Configure build settings:** Netlify will automatically detect that this is a Next.js project. The default settings are usually correct:
    *   **Build command:** `npm run build`
    *   **Publish directory:** `.next`
6.  **Add Environment Variables:** Before deploying, you must add your Gemini API key.
    *   Go to **Site settings > Build & deploy > Environment**.
    *   Click **"Edit variables"** and add a new variable:
        *   **Key:** `GEMINI_API_KEY`
        *   **Value:** `your_api_key_here` (Paste your actual key here).
7.  **Authorize the Deployment Domain in Firebase:**
    *   Go to your [Firebase Console](https://console.firebase.google.com/).
    *   Select your project.
    *   Navigate to **Authentication** > **Settings** > **Authorized domains**.
    *   Click **"Add domain"** and enter your Netlify app's domain (e.g., `familyfinanceflowapp.netlify.app`). This is a critical security step to allow users to log in from your live site.
8.  Click **"Deploy site"**. Netlify will start the build and deployment process. Once complete, your site will be live.

## Running the Project Locally

1.  **Install dependencies:**
    ```bash
    npm install
    ```

2.  **Set up environment variables:**
    Create a `.env` file in the root of the project and add your Gemini API key:
    ```
    GEMINI_API_KEY=your_api_key_here
    ```

3.  **Run the development server:**
    ```bash
    npm run dev
    ```

    Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.
